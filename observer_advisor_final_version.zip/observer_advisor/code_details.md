
Read graph.py, lines 105 to 140

---
Step1: Connect to DB and get resutls. Here's what run_tools_node does:
---
Gets the list of apps to check — reads tools_to_run from state (e.g. ["ascm", "ate", "promptopt"])

Loops through each app and looks up its DB check function from TOOLS_MAP:

"ascm" → calls check_ascm() from tools/ascm_tool.py

"ate" → calls check_ate() from tools/ate_tool.py

"promptopt" → calls check_promptopt() from tools/promptopt_tool.py

Each tool function runs a SQL query against its database (sample SQLite or prod PostgreSQL/Oracle depending on config), and returns a dict like:

If a tool fails, it catches the exception and still appends a result with "error": "..." so downstream steps know it failed rather than silently skipping.

Returns {"raw_results": [result1, result2, result3]} — a list of all raw DB check results.

No LLM, no RAG — this is purely deterministic SQL queries

---
normalize_node — Step 2: Normalization + LLM Enrichment
Two phases: This happens in two phases
---

Phase 1 — Deterministic normalization (no LLM):

Calls normalize_all(raw_results) from steps/normalizer.py
Takes the raw DB results from Step 1 (different shapes for each app) and converts them into a uniform NormalizedSignal format with standard fields: signal_id, application, observed_value, expected_value, evidence, etc.
Example: ASCM raw result {"raw_value": "2026-05-03"} → signal with observed_value="2026-05-03", expected_value="2026-05-08" (today's date)

Normalization rules are defined in _normalize_ascm, _normalize_ate, _normalize_promptopt files from steps/normalizer.py file

Phase 2 — LLM enrichment (wrapped in try/except):

Loops through each normalized signal
Calls build_enrichment_prompt(signal) → builds a prompt from the signal data using the template in prompts/normalizer_prompts.py
Sends prompt to Azure OpenAI GPT-4o
Calls apply_enrichment(signal, llm_output) → parses the LLM response and adds an interpretation field to the signal (e.g. "The target date is 5 days behind schedule")
Stores llm_input and llm_output in the signal's evidence dict for traceability in the UI
If LLM fails, the pipeline continues with un-enriched signals — the deterministic normalization always succeeds.

Returns {"signals": [signal1_dict, signal2_dict, ...]} — list of normalized + enriched signal dicts.