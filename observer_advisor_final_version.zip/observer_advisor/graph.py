"""LangGraph graph definition for Observer Agent pipeline.

Flow (per-app isolation):
  Step 1: run_tools (all apps at once) → raw results
  Pre-check: Is raw data healthy?
    YES → skip Steps 2-5 (log only)
    NO  → Step 2: normalize → Step 3: detect (→ save to DB)
                                  ↓ (normal behavior) → END
                                  ↓ (anomaly) → Step 4 → Step 5 (→ update DB) → END
"""

from __future__ import annotations

import json
import logging
import os

from langchain_openai import AzureChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import StateGraph, END
from langgraph.prebuilt import ToolNode

from observer_advisor.config import get_config
from observer_advisor.state import ObserverState
from observer_advisor.tools.ascm_tool import check_ascm
from observer_advisor.tools.ate_tool import check_ate
from observer_advisor.tools.promptopt_tool import check_promptopt
from observer_advisor.steps.normalizer import (
    normalize_all, NormalizedSignal, build_enrichment_prompt, apply_enrichment,
)
from observer_advisor.steps.detector import (
    run_detection, build_explanation_prompt, run_soft_anomaly_detection,
)
from observer_advisor.steps.validator import validate_detections
from observer_advisor.steps.correlator import (
    correlate, suppress, build_correlation_prompt, apply_correlation_narrative,
)
from observer_advisor.steps.router import (
    route, build_description_prompt, _compute_severity,
)
from observer_advisor.tools.azure_rag import retrieve_logs
from observer_advisor.steps.db_persistence import (
    save_observation, update_incident_details, save_step_output,
)
from observer_advisor.logging_config import LLM_LOGGER

# from observer_advisor.tools.email_notification import send_incident_email

logger = logging.getLogger(__name__)
llm_logger = logging.getLogger(LLM_LOGGER)

# ── Tools ─────────────────────────────────────────────────────────────────────

# ── Tools registry ────────────────────────────────────────────────────────────

TOOLS_MAP = {
    "ascm": check_ascm,
    "ate": check_ate,
    "promptopt": check_promptopt,
}


# ── LLM setup ────────────────────────────────────────────────────────────────

def _get_llm():
    cfg = get_config().llm
    return AzureChatOpenAI(
        azure_endpoint=cfg.api_base,
        api_key=cfg.api_key,
        api_version=cfg.api_version,
        azure_deployment=cfg.deployment,
        temperature=cfg.temperature,
    )


# ── Node functions ────────────────────────────────────────────────────────────

def run_tools_node(state: ObserverState) -> dict:
    """Node 1: Call only the DB tools that are due for this cycle."""
    tools_to_run = state.get("tools_to_run", list(TOOLS_MAP.keys()))
    logger.info(f"=== Running DB check tools: {tools_to_run} ===")
    raw_results = []

    for name in tools_to_run:
        tool_fn = TOOLS_MAP.get(name)
        if tool_fn is None:
            logger.warning(f"Unknown tool: {name}")
            continue
        try:
            result = tool_fn.invoke({})
            raw_results.append(result)
            logger.info(f"Tool {name} returned: {result.get('application', 'unknown')}")
        except Exception as e:
            logger.error(f"Tool {name} failed: {e}")
            raw_results.append({
                "application": name.upper(),
                "error": str(e),
            })

    return {"raw_results": raw_results}


def normalize_node(state: ObserverState) -> dict:
    """Node 2: Normalize & enrich raw results into canonical signals.
    LLM enriches each signal with interpretation & business context."""
    logger.info("=== Step 2: Normalization & Enrichment ===")
    raw_results = state.get("raw_results", [])
    
    # step 1: enrichment without LLM calls to get initial signals for RAG context in later steps
    signals = normalize_all(raw_results)

    # LLM enrichment for each signal: step 2: LLM enrichment
    try:
        llm = _get_llm()
        for signal in signals:
            prompt = build_enrichment_prompt(signal)
            # llm_logger.info(f"[Step2] [{signal.application.value}] Enrichment prompt for {signal.signal_id}")
            llm_logger.info(f"[Step2] [{signal.application.value}] Enrichment prompt for {signal.check_id}")
            llm_logger.info(f"[Step2] PROMPT:\n{prompt}")
            response = llm.invoke([HumanMessage(content=prompt)])
            llm_output = response.content
            # llm_logger.info(f"[Step2] [{signal.application.value}] Response received for {signal.signal_id}")
            llm_logger.info(f"[Step2] [{signal.application.value}] Response received for {signal.check_id}")
            llm_logger.info(f"[Step2] RESPONSE:\n{llm_output}")
            apply_enrichment(signal, llm_output)
            # Store LLM input/output in evidence for traceability
            signal.evidence["llm_input"] = prompt
            signal.evidence["llm_output"] = llm_output
            # logger.info(f"Enriched signal {signal.signal_id}")
            logger.info(f"Enriched signal {signal.check_id}")
    except Exception as e:
        logger.warning(f"LLM enrichment failed (continuing without): {e}")

    return {"signals": [s.model_dump() for s in signals]}


def detect_and_validate_node(state: ObserverState) -> dict:
    """Node 3: Detection + Validation (merged Step 3 + 3A).
    1. Run detection rules (deterministic or LLM-based)
    2. LLM explains each triggered detection
    3. Validate against business context (holiday, maintenance, hours, false positives)
    4. Return validated detections (suppressed ones marked excluded)"""
    logger.info("=== Step 3: Detection & Validation ===")
    signal_dicts = state.get("signals", [])
    signals = [NormalizedSignal(**s) for s in signal_dicts]
    signal_map = {s.check_id: s for s in signals}

    # ── 3a: Detection ──
    use_llm = get_config().use_llm_detection
    if use_llm:
        from observer_advisor.steps.detector import run_llm_detection
        logger.info("Using LLM-based detection")
        llm = _get_llm()
        app_names = {s.application.value for s in signals}
        rag_parts = []
        for app_name in app_names:
            ctx = retrieve_logs(
                query=" ".join(s.check_id for s in signals if s.application.value == app_name),
                application=app_name,
            )
            if ctx:
                rag_parts.append(ctx)
        rag_context = "\n\n".join(rag_parts)
        detections = run_llm_detection(signals, llm, rag_context=rag_context)
    else:
        detections = run_detection(signals)

    # LLM explanation for each triggered detection
    if detections:
        try:
            llm = _get_llm()
            for det in detections:
                signal = signal_map.get(det.check_id)
                if signal:
                    rag_context = retrieve_logs(
                        query=det.evidence,
                        application=det.application.value,
                    )
                    messages = build_explanation_prompt(det, signal, rag_context=rag_context)
                    prompt = "\n---\n".join(m.content for m in messages)
                    llm_logger.info(f"[Step3] [{det.application.value}] Explanation prompt for {det.incident_id}")
                    llm_logger.info(f"[Step3] PROMPT:\n{prompt}")
                    response = llm.invoke(messages)
                    llm_output = response.content.strip()
                    llm_logger.info(f"[Step3] [{det.application.value}] Response received for {det.incident_id}")
                    llm_logger.info(f"[Step3] RESPONSE:\n{llm_output}")
                    det.evidence += f" | LLM: {llm_output}"
                    det._rag_context = rag_context
                    logger.info(f"LLM explained detection {det.incident_id}")
        except Exception as e:
            logger.warning(f"LLM explanation failed (continuing without): {e}")

    # Build detection dicts with llm_input/llm_output/rag_context
    det_dicts = []
    for det in detections:
        d = det.model_dump()
        signal = signal_map.get(det.check_id)
        rag_ctx = getattr(det, '_rag_context', '')
        if signal:
            d["llm_input"] = build_explanation_prompt(det, signal, rag_context=rag_ctx)
        d["llm_output"] = det.evidence.split("| LLM: ", 1)[1] if "| LLM: " in det.evidence else None
        d["rag_context"] = rag_ctx
        det_dicts.append(d)

    # ── 3b: Validation (business context) ──
    if not det_dicts:
        logger.info("No detections to validate.")
        all_validations = []
        active_detections = []
    else:
        try:
            val_llm = _get_llm()
        except Exception as e:
            logger.warning(f"Could not initialize LLM for validation: {e}")
            val_llm = None

        validated = validate_detections(det_dicts, llm=val_llm)

        # Log LLM I/O for traceability
        for det in validated:
            if det.get("validation_llm_input") or det.get("validation_llm_output"):
                llm_logger.info(f"[Step3A] [{det.get('application', '?')}] Validation for {det.get('rule_name', '?')}")
                if det.get("validation_llm_input"):
                    llm_logger.info(f"[Step3A] PROMPT:\n{det['validation_llm_input']}")
                if det.get("validation_llm_output"):
                    llm_logger.info(f"[Step3A] RESPONSE:\n{det['validation_llm_output']}")

        # All validations (including suppressed) for UI display
        all_validations = [det.copy() for det in validated]

        # Only keep non-suppressed detections for downstream steps
        active_detections = [det for det in validated if det.get("validation", {}).get("included", True)]

        logger.info(f"Step 3 complete: {len(det_dicts)} detected → {len(active_detections)} active, "
                    f"{len(det_dicts) - len(active_detections)} suppressed")

    # ── 3c: Soft Anomaly Discovery (Step 3B) ──
    soft_anomalies = []
    try:
        import json as _json
        baselines_path = os.path.join(os.path.dirname(__file__), "config", "baselines.json")
        with open(baselines_path, "r") as f:
            baselines = _json.load(f)

        soft_llm = _get_llm()

        # RAG context for soft anomaly analysis
        app_names = {s.application.value for s in signals}
        soft_rag_parts = []
        for app_name in app_names:
            ctx = retrieve_logs(
                query=f"soft anomaly baseline deviation {app_name}",
                application=app_name,
            )
            if ctx:
                soft_rag_parts.append(ctx)
        soft_rag_context = "\n\n".join(soft_rag_parts)

        soft_anomalies = run_soft_anomaly_detection(
            signals=signals,
            llm=soft_llm,
            baselines=baselines,
            rag_context=soft_rag_context,
        )

        # Log LLM I/O for traceability
        for sa in soft_anomalies:
            llm_logger.info(f"[Step3B] [{sa.get('application', '?')}] Soft anomaly: {sa.get('check_id', '?')}")
            if sa.get("llm_input"):
                llm_logger.info(f"[Step3B] PROMPT:\n{sa['llm_input']}")
            if sa.get("llm_output"):
                llm_logger.info(f"[Step3B] RESPONSE:\n{sa['llm_output']}")

        logger.info(f"Step 3B complete: {len(soft_anomalies)} soft anomalies found")
    except Exception as e:
        logger.warning(f"Step 3B soft anomaly detection failed (continuing without): {e}")

    return {"validations": all_validations, "detections": active_detections, "soft_anomalies": soft_anomalies}


def should_continue(state: ObserverState) -> str:
    """Edge: If no anomalies detected, skip to END."""
    detections = state.get("detections", [])
    if not detections:
        logger.info("No anomalies detected — ending pipeline.")
        return "end"
    logger.info(f"{len(detections)} anomalies detected — continuing to correlation.")
    return "correlate"


def correlate_node(state: ObserverState) -> dict:
    """Node 4: Correlate & suppress detections into incident candidates.
    Grouping is deterministic. LLM generates correlation narrative."""
    from observer_advisor.models.signals import Detection as DetectionModel
    logger.info("=== Step 4: Correlation & Suppression ===")
    det_dicts = state.get("detections", [])
    detections = [DetectionModel(**{k: v for k, v in d.items() if k not in ("llm_input", "llm_output")}) for d in det_dicts]
    candidates = correlate(detections)
    candidates = suppress(candidates)

    # LLM correlation narrative for each incident candidate
    llm_traces: dict[str, dict] = {}  # incident_id -> {input, output}
    try:
        llm = _get_llm()
        for candidate in candidates:
            # RAG: retrieve relevant logs for this application
            evidence_query = " ".join(
                d.evidence for d in candidate.contributing_detections
            )
            rag_context = retrieve_logs(
                query=evidence_query,
                application=candidate.application.value,
            )

            # Knowledge graph context (only if USE_GRAPH_DB=true)
            graph_context = ""
            if get_config().use_graph_db:
                try:
                    from observer_advisor.tools.knowledge_graph import get_graph_context_for_apps
                    graph_context = get_graph_context_for_apps(
                        candidate.application.value, candidate.application.value
                    )
                except Exception as kg_err:
                    logger.warning(f"Knowledge graph query failed: {kg_err}")
                    
            if not graph_context:
                try:
                    from observer_advisor.tools.azure_rag import retrieve_graph_context
                    graph_context = retrieve_graph_context(
                        query=evidence_query,
                        application=candidate.application.value,
                    )
                except Exception as vdb_err:
                    logger.warning(f"Vector DB graph context retrieval failed: {vdb_err}")

            messages = build_correlation_prompt(candidate, rag_context=rag_context, graph_context=graph_context)
            prompt = "\n---\n".join(m.content for m in messages)  # for logging
            llm_logger.info(f"[Step4] [{candidate.application.value}] Correlation prompt for {candidate.incident_id}")
            llm_logger.info(f"[Step4] RAG Context:\n{rag_context or 'No logs available.'}")
            graph_source = "Cosmos Gremlin" if (get_config().use_graph_db and graph_context) else "Azure AI Search"
            llm_logger.info(f"[Step4] Graph Context (source: {graph_source}):\n{graph_context or 'No graph context available.'}")
            llm_logger.info(f"[Step4] PROMPT:\n{prompt}")
            response = llm.invoke(messages)
            llm_output = response.content
            llm_logger.info(f"[Step4] [{candidate.application.value}] Response received for {candidate.incident_id}")
            llm_logger.info(f"[Step4] RESPONSE:\n{llm_output}")
            apply_correlation_narrative(candidate, llm_output)
            llm_traces[candidate.incident_id] = {
                "llm_input": prompt,
                "llm_output": llm_output,
                "rag_context": rag_context,
                "graph_context": graph_context,
            }
    except Exception as e:
        logger.warning(f"LLM correlation failed (continuing without): {e}")

    # Attach llm_input/llm_output to each candidate dict
    inc_dicts = []
    for c in candidates:
        d = c.model_dump()
        trace = llm_traces.get(c.incident_id, {})
        d["llm_input"] = trace.get("llm_input")
        d["llm_output"] = trace.get("llm_output")
        d["rag_context"] = trace.get("rag_context")
        d["graph_context"] = trace.get("graph_context")
        inc_dicts.append(d)

    return {"incidents": inc_dicts}


def route_node(state: ObserverState) -> dict:
    """Node 5: Severity scoring & routing.
    Severity is deterministic. LLM generates incident description."""
    from observer_advisor.models.signals import IncidentCandidate, Detection as DetectionModel
    logger.info("=== Step 5: Severity & Routing ===")
    inc_dicts = state.get("incidents", [])

    candidates = []
    for d in inc_dicts:
        # Strip llm_input/llm_output/rag_context before reconstructing model
        clean = {k: v for k, v in d.items() if k not in ("llm_input", "llm_output", "rag_context", "graph_context")}
        dets = [DetectionModel(**{k: v for k, v in det.items() if k not in ("llm_input", "llm_output", "rag_context", "graph_context")})
                for det in clean.get("contributing_detections", [])]
        clean["contributing_detections"] = dets
        candidates.append(IncidentCandidate(**clean))

    incidents = route(candidates)

    # LLM-generated incident description for each incident
    llm_traces: dict[str, dict] = {}  # incident_id -> {input, output}
    try:
        llm = _get_llm()
        for i, incident in enumerate(incidents):
            candidate = candidates[i] if i < len(candidates) else None
            if candidate:
                # RAG: retrieve relevant logs for this application
                evidence_query = " ".join(
                    d.evidence for d in candidate.contributing_detections
                )
                rag_context = retrieve_logs(
                    query=evidence_query,
                    application=candidate.application.value,
                )
                messages = build_description_prompt(candidate, incident.severity, rag_context=rag_context)
                prompt = "\n---\n".join(m.content for m in messages)  # for logging
                llm_logger.info(f"[Step5] [{candidate.application.value}] Description prompt for {incident.incident_id}")
                llm_logger.info(f"[Step5] PROMPT:\n{prompt}")
                response = llm.invoke(messages)
                llm_output = response.content.strip()
                llm_logger.info(f"[Step5] [{candidate.application.value}] Response received for {incident.incident_id}")
                llm_logger.info(f"[Step5] RESPONSE:\n{llm_output}")
                incident.description = llm_output
                llm_traces[incident.incident_id] = {
                    "llm_input": prompt,
                    "llm_output": llm_output,
                    "rag_context": rag_context,
                }

                logger.info(f"LLM described incident {incident.incident_id}")
    except Exception as e:
        logger.warning(f"LLM description failed (keeping default): {e}")

    # Attach llm_input/llm_output to each incident dict
    graph_ctx_map = {d.get("incident_id"): d.get("graph_context") for d in inc_dicts}
    final_dicts = []
    for inc in incidents:
        d = inc.model_dump()
        trace = llm_traces.get(inc.incident_id, {})
        d["llm_input"] = trace.get("llm_input")
        d["llm_output"] = trace.get("llm_output")
        d["rag_context"] = trace.get("rag_context")
        d["graph_context"] = graph_ctx_map.get(inc.incident_id)
        final_dicts.append(d)

    return {"final_incidents": final_dicts}


# ── Build Graphs ──────────────────────────────────────────────────────────────

def build_check_graph():
    """Build graph for Step 1 only (DB checks for all apps)."""
    graph = StateGraph(ObserverState)
    graph.add_node("run_tools", run_tools_node)
    graph.set_entry_point("run_tools")
    graph.add_edge("run_tools", END)
    return graph.compile()


def build_pipeline_graph():
    """Build graph for Steps 2-5 (single app at a time).
    Save nodes are omitted — combined results are saved by run_pipeline()."""
    graph = StateGraph(ObserverState)

    graph.add_node("normalize", normalize_node)
    graph.add_node("detect", detect_and_validate_node)
    graph.add_node("correlate", correlate_node)
    graph.add_node("route", route_node)

    graph.set_entry_point("normalize")
    graph.add_edge("normalize", "detect")

    graph.add_conditional_edges(
        "detect",
        should_continue,
        {"correlate": "correlate", "end": END},
    )

    graph.add_edge("correlate", "route")
    graph.add_edge("route", END)

    return graph.compile()


def _get_app_name(raw: dict) -> str:
    """Extract app name from a raw result dict."""
    return raw.get("application", "").upper()


APP_NAMES = {"ASCM": "ascm", "ATE": "ate", "PROMPTOPT": "promptopt"}


def _is_app_healthy(app_name: str, app_raw: list[dict]) -> bool:
    """Pre-check: decide if an app's raw data indicates healthy state.

    Returns True if the app is healthy and Steps 2-5 should be skipped.
    """
    cfg = get_config().thresholds

    if app_name == "ASCM":
        # ASCM query returns row_count for today's tgt_frequency rows
        for raw in app_raw:
            if raw.get("error"):
                return False  # query failed — investigate
            count = raw.get("row_count", 0)
            if count is None or int(count) == 0:
                return False  # data missing — investigate
        return True  # today's data present

    if app_name == "ATE":
        results = {}
        for raw in app_raw:
            if raw.get("error"):
                return False
            # ATE returns nested results dict
            for check_id, check_data in raw.get("results", {}).items():
                results[check_id] = check_data
            # Also handle flat structure
            if raw.get("check_id"):
                results[raw["check_id"]] = raw
        trade_errors = int(results.get("ate_trade_errors", {}).get("value", 0) or 0)
        sync_errors = int(results.get("ate_exchsync_errors", {}).get("value", 0) or 0)
        trade_count = int(results.get("ate_trade_count", {}).get("value", 0) or 0)
        if trade_errors > 0 or sync_errors > 0 or trade_count == 0:
            return False
        return True

    if app_name == "PROMPTOPT":
        results = {}
        for raw in app_raw:
            if raw.get("error"):
                return False
            for check_id, check_data in raw.get("results", {}).items():
                results[check_id] = check_data
            if raw.get("check_id"):
                results[raw["check_id"]] = raw
        errors = int(results.get("promptopt_errors", {}).get("value", 0) or 0)
        queue_depth = int(results.get("promptopt_queue_depth", {}).get("value", 0) or 0)
        if errors > 0 or queue_depth >= cfg.promptopt_queue_warning:
            return False
        activity = results.get("promptopt_activity", {}).get("value")
        if activity is None:
            return False
        return True

    # Unknown app — don't skip
    return False


def run_pipeline(tools_to_run: list[str] | None = None) -> dict:
    """Run the full pipeline with per-app isolation.

    Step 1: Check all apps (DB queries, no LLM).
    Steps 2-5: Run separately for each app that returned data.

    Returns:
        Combined results from all apps.
    """
    import uuid as _uuid
    from observer_advisor.models.signals import set_incident_counter
    from observer_advisor.tools.db_connections import get_results_connection
    run_id = str(_uuid.uuid4())
    
    # Initialize incident counter from DB max
    try:
        with get_results_connection() as conn:
            cur = conn.cursor()
            cur.execute(
                "SELECT incident_id FROM observation_log "
                "WHERE incident_id IS NOT NULL AND incident_id LIKE 'INC_%' "
                "ORDER BY incident_id DESC LIMIT 1"
            )
            row = cur.fetchone()
            if row and row[0]:
                max_num = int(row[0].replace("INC_", ""))
                set_incident_counter(max_num)
    except Exception as e:
        logger.warning(f"Could not initialize incident counter from DB: {e}")

    if tools_to_run is None:
        tools_to_run = list(TOOLS_MAP.keys())

    # ── Step 1: Check all apps ──
    logger.info(f"{'='*60}")
    logger.info(f"Step 1: Running DB checks for {tools_to_run}")
    logger.info(f"{'='*60}")

    check_graph = build_check_graph()
    step1_result = check_graph.invoke({
        "messages": [],
        "tools_to_run": tools_to_run,
        "raw_results": [],
        "signals": [],
        "detections": [],
        "validations": [],
        "soft_anomalies": [],
        "incidents": [],
        "final_incidents": [],
    })

    raw_results = step1_result.get("raw_results", [])

    # ── Group raw results by app ──
    app_results: dict[str, list[dict]] = {}
    for raw in raw_results:
        app = _get_app_name(raw)
        app_results.setdefault(app, []).append(raw)

    # Save Step 1 output per app
    for app_name, app_raw in app_results.items():
        save_step_output(run_id, 1, app_name, app_raw)

    # ── Pre-check: skip healthy apps ──
    apps_to_process: dict[str, list[dict]] = {}
    for app_name, app_raw in app_results.items():
        if _is_app_healthy(app_name, app_raw):
            logger.info(f"{app_name}: healthy, skipping Steps 2-5")
        else:
            apps_to_process[app_name] = app_raw

    # ── Steps 2-5: Run per app (only unhealthy) ──
    pipeline_graph = build_pipeline_graph()
    all_signals = []
    all_detections = []
    all_soft_anomalies = []
    all_incidents = []
    all_final_incidents = []

    for app_name, app_raw in apps_to_process.items():
        logger.info(f"\n{'='*60}")
        logger.info(f"Processing app: {app_name}")
        logger.info(f"{'='*60}")

        result = pipeline_graph.invoke({
            "messages": [],
            "tools_to_run": [],
            "raw_results": app_raw,
            "signals": [],
            "detections": [],
            "validations": [],
            "soft_anomalies": [],
            "incidents": [],
            "final_incidents": [],
        })

        all_signals.extend(result.get("signals", []))
        all_detections.extend(result.get("detections", []))
        all_soft_anomalies.extend(result.get("soft_anomalies", []))
        all_incidents.extend(result.get("incidents", []))
        all_final_incidents.extend(result.get("final_incidents", []))

        # Save step outputs per app
        save_step_output(run_id, 2, app_name, result.get("signals", []))
        # Step 3: save all validations (contains detection + validation metadata)
        save_step_output(run_id, 3, app_name, result.get("validations", []))
        # Step 3B: save soft anomalies (always save, even if empty, so UI knows 3B ran)
        soft_anoms = result.get("soft_anomalies", [])
        save_step_output(run_id, 6, app_name, soft_anoms)
        save_step_output(run_id, 4, app_name, result.get("incidents", []))
        save_step_output(run_id, 5, app_name, result.get("final_incidents", []))

        # ── Save observations to PostgreSQL (using validated results) ──
        validations_list = result.get("validations", [])
        det_list = result.get("detections", [])  # active only (for Step 5 matching)
        sig_list = result.get("signals", [])

        for val in validations_list:
            # Suppressed detections → NORMAL, active → ANOMALY
            is_suppressed = not val.get("validation", {}).get("included", True)
            status = "NORMAL" if is_suppressed else "ANOMALY"
            obs_id = save_observation(
                application=val.get("application", app_name),
                status=status,
                rule_name=val.get("rule_name", ""),
                evidence=val.get("evidence", ""),
                llm_explanation=val.get("llm_output"),
                rag_context=val.get("rag_context"),
                run_id=run_id,
                incident_id=val.get("incident_id"),
            )
            if obs_id:
                val["_observation_id"] = obs_id
                # Also set on matching active detection for Step 5 matching
                for det in det_list:
                    if det.get("incident_id") == val.get("incident_id"):
                        det["_observation_id"] = obs_id

        if not validations_list and sig_list:
            # No detections at all (NORMAL) — save signal info for the record
            for sig in sig_list:
                save_observation(
                    application=sig.get("application", app_name),
                    status="NORMAL",
                    rule_name=sig.get("check_id", "no_detection"),
                    evidence=sig.get("interpretation", ""),
                    llm_explanation=sig.get("evidence", {}).get("llm_output"),
                    rag_context=None,
                    run_id=run_id,
                )

        # ── Update DB with Step 5 incident details ──
        final_list = result.get("final_incidents", [])
        for inc in final_list:
            inc_id = inc.get("incident_id", "")
            # Each final incident corresponds to exactly one detection (1:1 mapping)
            inc_dets = inc.get("evidence_summary", {}).get("detections", [])
            for det in det_list:
                obs_id = det.get("_observation_id")
                if obs_id and inc_dets:
                    # Match by rule name
                    if any(d.get("rule") == det.get("rule_name") for d in inc_dets):
                        update_incident_details(
                            observation_id=obs_id,
                            severity=inc.get("severity"),
                            incident_id=inc_id,
                            correlation_narrative=inc.get("correlation_summary"),
                            incident_description=inc.get("description"),
                        )

        if final_list:
            for inc in final_list:
                # send_incident_email(inc)
                pass
            logger.info(f"{app_name}: {len(final_list)} incident(s) created")
        elif det_list:
            logger.info(f"{app_name}: {len(det_list)} detection(s), no incidents")
        else:
            logger.info(f"{app_name}: No anomalies detected")

    return {
        "raw_results": raw_results,
        "signals": all_signals,
        "detections": all_detections,
        "soft_anomalies": all_soft_anomalies,
        "incidents": all_incidents,
        "final_incidents": all_final_incidents,
    }


# Keep backward compatibility
def build_graph():
    """Backward-compatible: returns the pipeline graph for Steps 2-5."""
    return build_pipeline_graph()
