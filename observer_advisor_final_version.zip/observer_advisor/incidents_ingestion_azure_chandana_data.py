"""
Create Azure AI Search index and ingest incident data from Excel.
Fields: description, closing_notes, short_description, severity, service_offering, urgency, category, type
Filter field: service_offering (for ASCM, ATE, PromptOpt)
"""

import os
import pandas as pd
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex,
    SearchField,
    SearchFieldDataType,
    SimpleField,
    SearchableField,
    VectorSearch,
    HnswAlgorithmConfiguration,
    VectorSearchProfile,
    SearchableField,
)
from azure.core.credentials import AzureKeyCredential
from openai import AzureOpenAI
from dotenv import load_dotenv
import uuid

load_dotenv()

# ── Config ────────────────────────────────────────────────────
AZURE_SEARCH_ENDPOINT = os.getenv("AZURE_SEARCH_ENDPOINT", "https://ais-weu-poc-ai-01.search.windows.net")
AZURE_SEARCH_KEY = os.getenv("AZURE_SEARCH_KEY", "z5GYu4cBZqzPfNnFZSVPFaux4pxaHQeGknuN0sFsyVAzSeAmCv7M")
INDEX_NAME = os.getenv("AZURE_SEARCH_INDEX_NAME", "observer-incidents-one")
EXCEL_FILE = "UK_Incidents_ATE_ASCM_PO_6months.xlsx"  # <-- path to your Excel file


# ── 1. Create the index ──────────────────────────────────────

def create_index():
    index_client = SearchIndexClient(AZURE_SEARCH_ENDPOINT, AzureKeyCredential(AZURE_SEARCH_KEY))

    fields = [
        SimpleField(name="id", type=SearchFieldDataType.String, key=True),
        SearchableField(name="content", type=SearchFieldDataType.String, analyzer_name="standard.lucene"),
        SearchableField(name="short_description", type=SearchFieldDataType.String, analyzer_name="standard.lucene"),
        SearchableField(name="description", type=SearchFieldDataType.String, analyzer_name="standard.lucene"),
        SearchableField(name="closing_notes", type=SearchFieldDataType.String, analyzer_name="standard.lucene"),
        SimpleField(name="severity", type=SearchFieldDataType.String, filterable=True),
        SimpleField(name="service_offering", type=SearchFieldDataType.String, filterable=True),  # ASCM, ATE, PromptOpt
        SimpleField(name="urgency", type=SearchFieldDataType.String, filterable=True),
        SimpleField(name="category", type=SearchFieldDataType.String, filterable=True),
        SimpleField(name="type", type=SearchFieldDataType.String, filterable=True),
        SearchField(
            name="content_vector",
            type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
            searchable=True,
            vector_search_dimensions=3072,
            vector_search_profile_name="my-vector-profile",
        ),
    ]

    vector_search = VectorSearch(
        algorithms=[HnswAlgorithmConfiguration(name="my-hnsw")],
        profiles=[VectorSearchProfile(name="my-vector-profile", algorithm_configuration_name="my-hnsw")],
    )

    index = SearchIndex(name=INDEX_NAME, fields=fields, vector_search=vector_search)
    result = index_client.create_or_update_index(index)
    print(f"Index '{result.name}' created/updated successfully.")


# ── 2. Generate embedding ────────────────────────────────────

def get_embedding(text: str) -> list[float]:
    client = AzureOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", "https://ais-weu-poc-ai-01.openai.azure.com/"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY", "74d07689b48a4b0d97bc7e99736ee127"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21"),
    )
    response = client.embeddings.create(
        input=text,
        model=os.getenv("AZURE_EMBEDDING_DEPLOYMENT", "text-embedding-3-large"),
    )
    return response.data[0].embedding


# ── 3. Read Excel and upload ─────────────────────────────────

def ingest_from_excel():
    df = pd.read_excel(EXCEL_FILE)

    # Map Excel column names to index field names
    column_map = {
        "Short description": "short_description",
        "Close notes (Customer visible)": "closing_notes",
        "Description": "description",
        "Severity": "severity",
        "Service Offering": "service_offering",
        "Urgency": "urgency",
        "Category": "category",
        "Type": "type",
    }

    df = df.rename(columns=column_map)

    # Keep only the columns we need
    keep_cols = list(column_map.values())
    df = df[[c for c in keep_cols if c in df.columns]]

    # Fill NaN with empty strings
    df = df.fillna("")

    search_client = SearchClient(AZURE_SEARCH_ENDPOINT, INDEX_NAME, AzureKeyCredential(AZURE_SEARCH_KEY))

    docs = []
    for i, row in df.iterrows():
        # Build content string for embedding (combine key text fields)
        content = (
            f"Short Description: {row.get('short_description', '')}\n"
            f"Description: {row.get('description', '')}\n"
            f"Closing Notes: {row.get('closing_notes', '')}\n"
            f"Category: {row.get('category', '')}\n"
            f"Service Offering: {row.get('service_offering', '')}\n"
            f"Severity: {row.get('severity', '')}"
        )

        vector = get_embedding(content)

        doc = {
            "id": str(uuid.uuid4()),
            "content": content,
            "short_description": str(row.get("short_description", "")),
            "description": str(row.get("description", "")),
            "closing_notes": str(row.get("closing_notes", "")),
            "severity": str(row.get("severity", "")),
            "service_offering": str(row.get("service_offering", "")),
            "urgency": str(row.get("urgency", "")),
            "category": str(row.get("category", "")),
            "type": str(row.get("type", "")),
            "content_vector": vector,
        }
        docs.append(doc)

        # Upload in batches of 100
        if len(docs) == 100:
            result = search_client.upload_documents(docs)
            print(f"Uploaded batch, {i+1} rows processed")
            docs = []

    # Upload remaining
    if docs:
        result = search_client.upload_documents(docs)
        print(f"Uploaded final batch, total {len(df)} rows processed")

    print("Done! All documents ingested.")


# ── Run ───────────────────────────────────────────────────────

if __name__ == "__main__":
    print("Creating index...")
    create_index()
    print("\nIngesting data from Excel...")
    ingest_from_excel()