"""One-time script to populate the UK Power Trading knowledge graph
in Azure Cosmos DB (Gremlin API).

Usage:
    Set environment variables first:
        COSMOS_GREMLIN_ENDPOINT=wss://your-account.gremlin.cosmos.azure.com:443/
        COSMOS_GREMLIN_KEY=your-primary-key
        COSMOS_GREMLIN_DATABASE=your-database
        COSMOS_GREMLIN_GRAPH=your-graph

    Then run:
        python -m observer_advisor.scripts.populate_graph
"""

from __future__ import annotations

import sys
import time

from observer_advisor.tools.knowledge_graph import _get_client


def main():
    client = _get_client()

    # ── Vertices ──────────────────────────────────────────────────────────

    vertices = [
        # 1. Exchanges
        "g.addV('Exchange').property('id','exch:Trayport').property('pk','Exchange').property('name','Trayport').property('region','UK')",
        "g.addV('Exchange').property('id','exch:ICE').property('pk','Exchange').property('name','ICE').property('region','UK')",
        "g.addV('Exchange').property('id','exch:Nordpool').property('pk','Exchange').property('name','Nordpool').property('region','UK')",
        "g.addV('Exchange').property('id','exch:EPEX').property('pk','Exchange').property('name','EPEX').property('region','UK')",

        # 2. APIs
        "g.addV('API').property('id','api:JouleAPI').property('pk','API').property('name','Joule API')",
        "g.addV('API').property('id','api:EPEXAPI').property('pk','API').property('name','EPEX Web API')",
        "g.addV('API').property('id','api:N2EXAPI').property('pk','API').property('name','N2EX Clearing API')",
        "g.addV('API').property('id','api:AuctionAPI').property('pk','API').property('name','Auction API (UK/Conti)')",
        "g.addV('API').property('id','api:ASTAPI').property('pk','API').property('name','AST API')",
        "g.addV('API').property('id','api:M7AuctionAPI').property('pk','API').property('name','M7 Auction API')",

        # 3. Connectors
        "g.addV('Connector').property('id','conn:Trayport').property('pk','Connector').property('name','UKP Trayport Connector').property('function','Handles Trayport trade feed via API')",
        "g.addV('Connector').property('id','conn:ICE').property('pk','Connector').property('name','UKP ICE Connector').property('function','Handles ICE trade feed via middleware')",
        "g.addV('Connector').property('id','conn:Nordpool').property('pk','Connector').property('name','UKP Nordpool Connector').property('function','Handles Nordpool trades (N2EX)')",
        "g.addV('Connector').property('id','conn:EPEXAuction').property('pk','Connector').property('name','UKP EPEX Auction Connector').property('function','Handles EPEX auction results via API')",
        "g.addV('Connector').property('id','conn:CashOut').property('pk','Connector').property('name','UKP CashOut Connector').property('function','Handles cash-out trade adjustments')",
        "g.addV('Connector').property('id','conn:PosMan').property('pk','Connector').property('name','UKP PosMan Connector').property('function','Pushes trades to Fuse middleware')",

        # 4. Systems
        "g.addV('System').property('id','sys:ATE_Core').property('pk','System').property('name','ATE Core').property('systemType','ATE Component')",
        "g.addV('System').property('id','sys:ATE_EXCHSYNC').property('pk','System').property('name','ATE EXCHSYNC').property('systemType','ATE Component')",
        "g.addV('System').property('id','sys:ATE_API').property('pk','System').property('name','ATE API').property('systemType','ATE Component')",
        "g.addV('System').property('id','sys:UKP_Portal').property('pk','System').property('name','UK Power Portal').property('systemType','Portal')",
        "g.addV('System').property('id','sys:TradeEventListener').property('pk','System').property('name','Trade Event Listener').property('systemType','ATE Component')",
        "g.addV('System').property('id','sys:PosMan_AST').property('pk','System').property('name','PosMan AST').property('systemType','PosMan')",
        "g.addV('System').property('id','sys:PosMan_MGMT').property('pk','System').property('name','PosMan TradeMgmt').property('systemType','PosMan')",
        "g.addV('System').property('id','sys:Fuse').property('pk','System').property('name','Fuse Middleware').property('systemType','Middleware')",
        "g.addV('System').property('id','sys:Endur').property('pk','System').property('name','Endur').property('systemType','ETRM')",
        "g.addV('System').property('id','sys:Fenix').property('pk','System').property('name','Fenix').property('systemType','ETRM')",
        "g.addV('System').property('id','sys:MasterData').property('pk','System').property('name','Master Data Provider').property('systemType','ReferenceData')",
        "g.addV('System').property('id','sys:ATE_Data').property('pk','System').property('name','ATE Data Store').property('systemType','Database')",
        "g.addV('System').property('id','sys:PosMan_Auditor').property('pk','System').property('name','PosMan Data Auditor').property('systemType','Auditor')",
        "g.addV('System').property('id','sys:ATE_Auditor').property('pk','System').property('name','ATE Data Auditor').property('systemType','Auditor')",

        # 5. User
        "g.addV('User').property('id','user:Trader1').property('pk','User').property('name','Trader Alice').property('role','Trader')",

        # 6. Dynamic data vertices (samples)
        "g.addV('Trade').property('id','trd:T1001').property('pk','Trade').property('tradeId','T1001').property('type','ExchangeTrade').property('volume',50).property('commodity','Power').property('unit','MW')",
        "g.addV('Order').property('id','ord:O2001').property('pk','Order').property('orderId','O2001').property('type','AuctionOrder').property('volume',50).property('commodity','Power')",
        "g.addV('Message').property('id','msg:TradeXML1').property('pk','Message').property('messageType','TradeXML').property('status','Pending')",
        "g.addV('Position').property('id','pos:EndurPos1').property('pk','Position').property('positionType','DayAheadPosition').property('value',50)",
        "g.addV('Price').property('id','price:CashOut1').property('pk','Price').property('priceType','CashOutPrice').property('value',47.5)",
    ]

    # ── Edges ─────────────────────────────────────────────────────────────

    edges = [
        # Exchange -> Connector
        "g.V('exch:Trayport').addE('sendsMessage').to(g.V('conn:Trayport')).property('messageType','TradeMessage')",
        "g.V('exch:ICE').addE('sendsMessage').to(g.V('conn:ICE')).property('messageType','TradeMessage')",
        "g.V('exch:Nordpool').addE('sendsMessage').to(g.V('conn:Nordpool')).property('messageType','TradeMessage')",
        "g.V('exch:EPEX').addE('sendsMessage').to(g.V('conn:EPEXAuction')).property('messageType','AuctionResultMsg')",

        # Exchange/Connector -> API
        "g.V('exch:Trayport').addE('exposesAPI').to(g.V('api:JouleAPI'))",
        "g.V('conn:Trayport').addE('callsAPI').to(g.V('api:JouleAPI'))",
        "g.V('conn:Nordpool').addE('callsAPI').to(g.V('api:N2EXAPI'))",
        "g.V('conn:EPEXAuction').addE('callsAPI').to(g.V('api:EPEXAPI'))",
        "g.V('api:M7AuctionAPI').addE('callsAPI').to(g.V('api:AuctionAPI'))",
        "g.V('api:AuctionAPI').addE('callsAPI').to(g.V('api:ASTAPI'))",

        # Connector -> ATE EXCHSYNC
        "g.V('conn:Trayport').addE('sendsMessage').to(g.V('sys:ATE_EXCHSYNC')).property('messageType','TradeMessage')",
        "g.V('conn:ICE').addE('sendsMessage').to(g.V('sys:ATE_EXCHSYNC')).property('messageType','TradeMessage')",
        "g.V('conn:Nordpool').addE('sendsMessage').to(g.V('sys:ATE_EXCHSYNC')).property('messageType','OrderMessage')",
        "g.V('conn:EPEXAuction').addE('sendsMessage').to(g.V('sys:ATE_EXCHSYNC')).property('messageType','OrderMessage')",

        # Connector -> Master Data
        "g.V('conn:Trayport').addE('sendsMessage').to(g.V('sys:MasterData')).property('messageType','AliasMapping')",
        "g.V('conn:ICE').addE('sendsMessage').to(g.V('sys:MasterData')).property('messageType','AliasMapping')",
        "g.V('conn:Nordpool').addE('sendsMessage').to(g.V('sys:MasterData')).property('messageType','AliasMapping')",
        "g.V('conn:EPEXAuction').addE('sendsMessage').to(g.V('sys:MasterData')).property('messageType','AliasMapping')",

        # ATE EXCHSYNC -> Exchange (confirmations)
        "g.V('sys:ATE_EXCHSYNC').addE('confirmsTrade').to(g.V('exch:EPEX')).property('region','UK')",
        "g.V('sys:ATE_EXCHSYNC').addE('confirmsTrade').to(g.V('exch:Nordpool')).property('region','UK')",

        # ATE internal flows
        "g.V('sys:ATE_EXCHSYNC').addE('forwardsTo').to(g.V('sys:ATE_Core')).property('data','TradesAndOrders')",
        "g.V('sys:ATE_Core').addE('calls').to(g.V('sys:ATE_API')).property('purpose','TradePersist')",
        "g.V('sys:ATE_Core').addE('storesDataIn').to(g.V('sys:ATE_Data')).property('data','TradeRecords')",

        # UK Power Portal & trade events
        "g.V('user:Trader1').addE('submitsTrade').to(g.V('sys:UKP_Portal')).property('method','ManualEntry')",
        "g.V('sys:UKP_Portal').addE('emitsEvent').to(g.V('sys:TradeEventListener')).property('eventType','TradeCompletion')",
        "g.V('sys:TradeEventListener').addE('triggers').to(g.V('conn:PosMan')).property('action','CreateTrade')",

        # PosMan Connector -> Fuse
        "g.V('conn:PosMan').addE('sendsMessage').to(g.V('sys:Fuse')).property('messageType','TradeXML')",

        # Fuse -> ETRM
        "g.V('sys:Fuse').addE('sendsTrade').to(g.V('sys:Endur')).property('interface','EndurAdapter')",
        "g.V('sys:Fuse').addE('sendsTrade').to(g.V('sys:Fenix')).property('interface','FenixAdapter')",

        # ETRM -> PosMan (position updates)
        "g.V('sys:Endur').addE('publishesPosition').to(g.V('sys:PosMan_MGMT')).property('positionType','FinalPosition')",
        "g.V('sys:Fenix').addE('publishesPosition').to(g.V('sys:PosMan_MGMT')).property('positionType','FinalPosition')",

        # CashOut flows
        "g.V('conn:CashOut').addE('publishesPrice').to(g.V('price:CashOut1')).property('priceType','SettlementPrice')",
        "g.V('conn:CashOut').addE('sendsTrade').to(g.V('sys:Endur')).property('tradeType','CashOutTrade')",
        "g.V('conn:CashOut').addE('sendsTrade').to(g.V('sys:Fenix')).property('tradeType','CashOutTrade')",

        # Trade lifecycle
        "g.V('exch:EPEX').addE('producesTrade').to(g.V('trd:T1001')).property('context','AuctionResult')",
        "g.V('trd:T1001').addE('recordsIn').to(g.V('sys:PosMan_MGMT'))",
        "g.V('trd:T1001').addE('integratedIn').to(g.V('sys:Endur'))",
        "g.V('trd:T1001').addE('integratedIn').to(g.V('sys:Fenix'))",

        # Dependencies & auditing
        "g.V('sys:PosMan_MGMT').addE('dependsOn').to(g.V('conn:PosMan'))",
        "g.V('sys:ATE_Auditor').addE('audits').to(g.V('sys:ATE_Data'))",
        "g.V('sys:PosMan_Auditor').addE('audits').to(g.V('sys:PosMan_MGMT'))",
    ]

    # ── Execute ───────────────────────────────────────────────────────────

    all_queries = vertices + edges
    total = len(all_queries)
    success = 0
    failed = 0

    print(f"Populating knowledge graph: {len(vertices)} vertices + {len(edges)} edges = {total} queries")
    print("-" * 60)

    for i, query in enumerate(all_queries, 1):
        label = "VERTEX" if i <= len(vertices) else "EDGE"
        short = query[:80] + "..." if len(query) > 80 else query
        try:
            client.submit(query).all().result()
            success += 1
            print(f"  [{i}/{total}] {label} OK: {short}")
        except Exception as e:
            failed += 1
            print(f"  [{i}/{total}] {label} FAILED: {short}")
            print(f"           Error: {e}")
        time.sleep(0.1)  # Small delay to avoid throttling

    print("-" * 60)
    print(f"Done. Success: {success}, Failed: {failed}, Total: {total}")

    # Verify
    try:
        v_count = client.submit("g.V().count()").all().result()
        e_count = client.submit("g.E().count()").all().result()
        print(f"Graph now has {v_count[0]} vertices and {e_count[0]} edges.")
    except Exception as e:
        print(f"Verification query failed: {e}")


if __name__ == "__main__":
    main()
