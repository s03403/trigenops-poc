-- Observer-Advisor: observation_log table
-- Run this on your Azure PostgreSQL results database.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS observation_log (
    id                      UUID            PRIMARY KEY DEFAULT uuid_generate_v4(),
    timestamp               TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    application             VARCHAR(50)     NOT NULL,
    status                  VARCHAR(20)     NOT NULL,  -- NORMAL / ANOMALY
    rule_name               VARCHAR(100)    NOT NULL,
    observed_value          TEXT,
    expected_value          TEXT,
    evidence                TEXT,
    llm_explanation         TEXT,
    rag_context             TEXT,
    severity                VARCHAR(10),               -- P1 / P2 / P3 (anomaly only)
    incident_id             VARCHAR(100),              -- (anomaly only)
    correlation_narrative   TEXT,                       -- (anomaly only)
    incident_description    TEXT,                       -- (anomaly only)
    user_feedback           TEXT,
    feedback_timestamp      TIMESTAMPTZ
);

-- Index for common queries
CREATE INDEX IF NOT EXISTS idx_obs_app_ts ON observation_log (application, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_obs_status ON observation_log (status);
