"""Run this script to create observation_log and pipeline_run_log tables in prod PostgreSQL."""

import sys
from pathlib import Path

# Ensure imports work
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from dotenv import load_dotenv
load_dotenv(dotenv_path=Path(__file__).resolve().parent.parent / ".env")

from observer_advisor.tools.db_connections import get_results_connection

SQL = """
CREATE TABLE IF NOT EXISTS observation_log (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    run_id                  TEXT,
    timestamp               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    application             VARCHAR(50) NOT NULL,
    status                  VARCHAR(20) NOT NULL,
    rule_name               VARCHAR(100) NOT NULL,
    evidence                TEXT,
    llm_explanation         TEXT,
    rag_context             TEXT,
    severity                VARCHAR(10),
    incident_id             VARCHAR(100),
    correlation_narrative   TEXT,
    incident_description    TEXT,
    user_feedback           TEXT,
    feedback_timestamp      TIMESTAMPTZ,
    analysis_correct        TEXT,
    feedback_user_name      TEXT,
    feedback_user_id        TEXT
);

CREATE TABLE IF NOT EXISTS pipeline_run_log (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    run_id          TEXT NOT NULL,
    timestamp       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    step_number     INTEGER NOT NULL,
    application     TEXT NOT NULL,
    step_output     TEXT
);

CREATE INDEX IF NOT EXISTS idx_obs_app_ts ON observation_log (application, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_obs_status ON observation_log (status);
"""

with get_results_connection() as conn:
    cur = conn.cursor()
    cur.execute(SQL)
    conn.commit()
    print("Tables created successfully!")
