"""Step 4: Correlation & Suppression.

Groups related detections into single incident candidates.
Uses deterministic key-based + temporal grouping.
LLM generates the correlation narrative.

Input:  list of Detection
Output: list of IncidentCandidate
"""

from __future__ import annotations

import json
import logging
from datetime import date

from observer_advisor.models.enums import Application, DetectionResult
from observer_advisor.models.signals import Detection, IncidentCandidate
from langchain_core.messages import HumanMessage, SystemMessage
from observer_advisor.prompts.correlator_prompts import (
    CORRELATION_SYSTEM,
    CORRELATION_DEVELOPER,
    CORRELATION_USER,
)

logger = logging.getLogger(__name__)


# ── Deterministic grouping ────────────────────────────────────────────────────


def correlate(detections: list[Detection]) -> list[IncidentCandidate]:
    """Create one incident candidate per detection.

    Each detection gets its own independent incident so that every anomaly
    has a fully independent trail through Steps 4-5.
    """
    if not detections:
        return []

    candidates = []
    for det in detections:
        # key = f"{det.application.value}_{det.rule_name}_{date.today().isoformat()}"
        key = f"{det.application.value}_{det.check_id}_{date.today().isoformat()}"

        candidate = IncidentCandidate(
            incident_id=det.incident_id,
            application=det.application,
            dedupe_key=key,
            contributing_detections=[det],
            business_date=date.today(),
        )
        candidates.append(candidate)
        logger.info(
            f"Correlated incident {candidate.incident_id}: "
            f"detection {det.rule_name} for {det.application.value}"
        )

    logger.info(f"Correlation complete: {len(candidates)} incidents from {len(detections)} detections")
    return candidates


# ── Suppression ───────────────────────────────────────────────────────────────

# In-memory store of active incident keys (reset on restart).
# In production, use Redis or a DB table.
_active_incidents: dict[str, str] = {}


def suppress(candidates: list[IncidentCandidate]) -> list[IncidentCandidate]:
    """Filter out already-reported incidents (same dedupe key).

    Returns only new or updated candidates.
    """
    new_candidates = []
    for c in candidates:
        if c.dedupe_key in _active_incidents:
            logger.info(f"Suppressed duplicate incident: {c.dedupe_key}")
            continue
        _active_incidents[c.dedupe_key] = c.incident_id
        new_candidates.append(c)

    return new_candidates


def clear_suppression_cache():
    """Clear the suppression cache (useful for testing or daily reset)."""
    _active_incidents.clear()


# ── LLM helper ───────────────────────────────────────────────────────────────

def build_correlation_prompt(candidate: IncidentCandidate, rag_context: str = "", graph_context: str = "") -> list:
    """Build multi-message prompt for LLM to generate correlation narrative.

    Returns a list of LangChain messages:
      [SystemMessage, HumanMessage (developer instruction), HumanMessage (user data)]
    """
    detections_data = [
        {
            "check_id": d.check_id,
            "rule_name": d.rule_name,
            "result": d.result.value,
            "evidence": d.evidence,
            "application": d.application.value,
        }
        for d in candidate.contributing_detections
    ]
    user_content = CORRELATION_USER.format(
        detections_json=json.dumps(detections_data, indent=2),
        rag_context=rag_context or "No logs available.",
        graph_context=graph_context or "No architectural context available.",
    )
    return [
        SystemMessage(content=CORRELATION_SYSTEM),
        HumanMessage(content=CORRELATION_DEVELOPER),
        HumanMessage(content=user_content),
    ]


def _strip_markdown_fences(text: str) -> str:
    """Remove ```json ... ``` fences from LLM output."""
    import re
    match = re.search(r"```(?:json)?\s*\n?(.*?)\n?\s*```", text, re.DOTALL)
    return match.group(1).strip() if match else text.strip()


def apply_correlation_narrative(
    candidate: IncidentCandidate, llm_response: str
) -> IncidentCandidate:
    """Apply LLM correlation narrative to a candidate."""
    try:
        cleaned = _strip_markdown_fences(llm_response)
        parsed = json.loads(cleaned)
        candidate.likely_cause = parsed.get("likely_cause")
        candidate.correlation_summary = parsed.get("correlation_narrative", cleaned)
    except (json.JSONDecodeError, Exception):
        candidate.correlation_summary = llm_response
    return candidate
