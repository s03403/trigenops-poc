"""Persistence for observation_log table.

Writes Step 3 results (both NORMAL and ANOMALY) to the results DB.
Updates incident details after Step 5.
Updates user feedback from Streamlit dashboard.
Supports both PostgreSQL (production) and SQLite (testing).
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone

from observer_advisor.tools.db_connections import get_results_connection

logger = logging.getLogger(__name__)


def _ph() -> str:
    """Return the correct SQL placeholder based on DB type."""
    from observer_advisor.config import get_config
    return "?" if get_config().use_sample_results else "%s"


def save_observation(
    application: str,
    status: str,
    rule_name: str,
    evidence: str | None = None,
    llm_explanation: str | None = None,
    rag_context: str | None = None,
    run_id: str | None = None,
    incident_id: str | None = None,
) -> str | None:
    """Insert a new observation row into observation_log.

    Called after Step 3 for both NORMAL and ANOMALY outcomes.

    Returns:
        The UUID of the inserted row, or None if the insert failed.
    """
    row_id = str(uuid.uuid4())
    p = _ph()
    try:
        with get_results_connection() as conn:
            cur = conn.cursor()
            cur.execute(
                f"""
                INSERT INTO observation_log
                    (id, run_id, timestamp, application, status, rule_name,
                     evidence, llm_explanation, rag_context, incident_id)
                VALUES ({p}, {p}, {p}, {p}, {p}, {p}, {p}, {p}, {p}, {p})
                """,
                (
                    row_id,
                    run_id,
                    datetime.now(timezone.utc).isoformat(),
                    application,
                    status,
                    rule_name,
                    evidence,
                    llm_explanation,
                    rag_context,
                    incident_id,
                ),
            )
            conn.commit()
            logger.info(f"Observation saved: {application} {status} id={row_id}")
            return row_id
    except Exception as e:
        logger.error(f"Failed to save observation: {e}")
        return None


def update_incident_details(
    observation_id: str,
    severity: str | None = None,
    incident_id: str | None = None,
    correlation_narrative: str | None = None,
    incident_description: str | None = None,
) -> bool:
    """Update an observation row with Step 4-5 incident details.

    Called after Step 5 for ANOMALY outcomes.
    """
    p = _ph()
    try:
        with get_results_connection() as conn:
            cur = conn.cursor()
            cur.execute(
                f"""
                UPDATE observation_log
                SET severity = {p},
                    incident_id = {p},
                    correlation_narrative = {p},
                    incident_description = {p}
                WHERE id = {p}
                """,
                (severity, incident_id, correlation_narrative,
                 incident_description, observation_id),
            )
            conn.commit()
            logger.info(f"Incident details updated for observation {observation_id}")
            return True
    except Exception as e:
        logger.error(f"Failed to update incident details: {e}")
        return False


def update_feedback(
    observation_id: str,
    feedback: str,
    analysis_correct: str = "",
    user_name: str = "",
    user_id: str = "",
) -> bool:
    """Update user feedback on an observation row.

    Called from Streamlit dashboard when user submits feedback.
    """
    p = _ph()
    try:
        with get_results_connection() as conn:
            cur = conn.cursor()
            cur.execute(
                f"""
                UPDATE observation_log
                SET user_feedback = {p},
                    feedback_timestamp = {p},
                    analysis_correct = {p},
                    feedback_user_name = {p},
                    feedback_user_id = {p}
                WHERE id = {p}
                """,
                (feedback, datetime.now(timezone.utc).isoformat(),
                 analysis_correct, user_name, user_id, observation_id),
            )
            conn.commit()
            logger.info(f"Feedback updated for observation {observation_id}")
            return True
    except Exception as e:
        logger.error(f"Failed to update feedback: {e}")
        return False


def get_observations(limit: int = 50) -> list[dict]:
    """Fetch recent observations for the Streamlit feedback dropdown.

    Returns list of dicts with all columns.
    """
    p = _ph()
    try:
        with get_results_connection() as conn:
            cur = conn.cursor()
            cur.execute(
                f"""
                SELECT id, run_id, timestamp, application, status, rule_name,
                       evidence, llm_explanation, rag_context,
                       severity, incident_id,
                       correlation_narrative, incident_description,
                       user_feedback, feedback_timestamp,
                       analysis_correct, feedback_user_name, feedback_user_id
                FROM observation_log
                ORDER BY timestamp DESC
                LIMIT {p}
                """,
                (limit,),
            )
            columns = [desc[0] for desc in cur.description]
            rows = cur.fetchall()
            return [dict(zip(columns, row)) for row in rows]
    except Exception as e:
        logger.error(f"Failed to fetch observations: {e}")
        return []


def save_step_output(
    run_id: str,
    step_number: int,
    application: str,
    step_output: list | dict,
) -> bool:
    """Save a pipeline step's output to pipeline_run_log."""
    import json
    row_id = str(uuid.uuid4())
    p = _ph()
    try:
        with get_results_connection() as conn:
            cur = conn.cursor()
            cur.execute(
                f"""
                INSERT INTO pipeline_run_log
                    (id, run_id, timestamp, step_number, application, step_output)
                VALUES ({p}, {p}, {p}, {p}, {p}, {p})
                """,
                (
                    row_id,
                    run_id,
                    datetime.now(timezone.utc).isoformat(),
                    step_number,
                    application,
                    json.dumps(step_output, default=str),
                ),
            )
            conn.commit()
            logger.info(f"Step {step_number} output saved for {application} run={run_id}")
            return True
    except Exception as e:
        logger.error(f"Failed to save step output: {e}")
        return False


def get_step_outputs(run_id: str, application: str) -> list[dict]:
    """Fetch all step outputs for a given run_id and application.

    Returns list of dicts with step_number and step_output (parsed JSON).
    """
    import json
    p = _ph()
    try:
        with get_results_connection() as conn:
            cur = conn.cursor()
            cur.execute(
                f"""
                SELECT step_number, step_output
                FROM pipeline_run_log
                WHERE run_id = {p} AND application = {p}
                ORDER BY step_number
                """,
                (run_id, application),
            )
            rows = cur.fetchall()
            results = []
            for row in rows:
                try:
                    output = json.loads(row[1]) if row[1] else None
                except (json.JSONDecodeError, TypeError):
                    output = row[1]
                results.append({"step_number": row[0], "step_output": output})
            return results
    except Exception as e:
        logger.error(f"Failed to fetch step outputs: {e}")
        return []
        return []
