"""Step 3: Detection Engine.

Applies deterministic rules to normalized signals to decide:
  PASS / WARNING / FAIL

LLM is used ONLY to explain triggered detections (not to decide).

Input:  list of NormalizedSignal
Output: list of Detection
"""

from __future__ import annotations
import json

import logging
from datetime import date, datetime

from observer_advisor.config import get_config
from observer_advisor.models.enums import (
    Application, DetectionResult, Severity, SignalType,
)
from observer_advisor.models.signals import NormalizedSignal, Detection, next_incident_id
from langchain_core.messages import HumanMessage, SystemMessage
from observer_advisor.prompts.detector_prompts import (
    DETECTION_SYSTEM,
    DETECTION_DEVELOPER,
    DETECTION_USER,
    LLM_DETECTION_SYSTEM,
    LLM_DETECTION_USER
)

logger = logging.getLogger(__name__)


# ── Rule functions ────────────────────────────────────────────────────────────

def _detect_ascm(signal: NormalizedSignal) -> Detection | None:
    """ASCM: Data freshness checks for multiple document types."""
    today = date.today()
    observed = signal.observed_value

    # Query error — applies to all ASCM checks
    if signal.evidence.get("error"):
        return Detection(
            incident_id=next_incident_id(),
            check_id=signal.check_id,
            application=Application.ASCM,
            result=DetectionResult.FAIL,
            rule_name=signal.check_id,
            evidence=f"Query failed: {signal.evidence['error']}",
            proposed_severity=Severity.P2,
        )

    if observed is None:
        return Detection(
            incident_id=next_incident_id(),
            check_id=signal.check_id,
            application=Application.ASCM,
            result=DetectionResult.FAIL,
            rule_name=signal.check_id,
            evidence=f"No data found for check {signal.check_id}",
            proposed_severity=Severity.P2,
        )

    # Count-based checks: ascm_tgt_frequency, ascm_fr
    if signal.check_id in ("ascm_tgt_frequency", "ascm_fr"):
        count = int(observed)
        if count == 0:
            return Detection(
                incident_id=next_incident_id(),
                check_id=signal.check_id,
                application=Application.ASCM,
                result=DetectionResult.FAIL,
                rule_name=signal.check_id,
                evidence=f"No {signal.check_id} data for today ({today})",
                proposed_severity=Severity.P2,
            )
        return Detection(
            incident_id=next_incident_id(),
            check_id=signal.check_id,
            application=Application.ASCM,
            result=DetectionResult.PASS,
            rule_name=signal.check_id,
            evidence=f"Found {count} records for today",
        )

    # Date freshness checks: ascm_avg_frequency, ascm_adjusted_pn
    if signal.check_id in ("ascm_avg_frequency", "ascm_adjusted_pn"):
        try:
            observed_date = date.fromisoformat(str(observed)[:10])
        except (ValueError, TypeError):
            return Detection(
                incident_id=next_incident_id(),
                check_id=signal.check_id,
                application=Application.ASCM,
                result=DetectionResult.WARNING,
                rule_name=signal.check_id,
                evidence=f"Cannot parse date: {observed}",
                proposed_severity=Severity.P3,
            )

        if observed_date < today:
            return Detection(
                incident_id=next_incident_id(),
                check_id=signal.check_id,
                application=Application.ASCM,
                result=DetectionResult.FAIL,
                rule_name=signal.check_id,
                evidence=f"Last update {observed_date} is behind today {today}",
                proposed_severity=Severity.P2,
            )
        return Detection(
            incident_id="",
            check_id=signal.check_id,
            application=Application.ASCM,
            result=DetectionResult.PASS,
            rule_name=signal.check_id,
            evidence=f"Data is fresh: {observed_date}",
        )

    # Legacy check_id support (Target Frequency)
    if signal.check_id == "Target Frequency":
        try:
            observed_date = date.fromisoformat(str(observed))
        except (ValueError, TypeError):
            observed_date = None

        if observed_date is None:
            return Detection(
                incident_id=next_incident_id(),
                check_id=signal.check_id,
                application=Application.ASCM,
                result=DetectionResult.WARNING,
                rule_name="ascm_tgt_frequency",
                evidence=f"Cannot parse TARGETDATE: {observed}",
                proposed_severity=Severity.P3,
            )

        if observed_date < today:
            return Detection(
                incident_id=next_incident_id(),
                check_id=signal.check_id,
                application=Application.ASCM,
                result=DetectionResult.FAIL,
                rule_name="ascm_tgt_frequency",
                evidence=f"TARGETDATE={observed_date} is behind today={today}",
                proposed_severity=Severity.P2,
            )

        return Detection(
            incident_id="",
            check_id=signal.check_id,
            application=Application.ASCM,
            result=DetectionResult.PASS,
            rule_name="ascm_tgt_frequency",
            evidence=f"TARGETDATE={observed_date} matches today={today}",
        )

    return None



def _detect_ate(signal: NormalizedSignal) -> Detection | None:
    """ATE: Trade stuck, trade failed, retry exhaustion checks.

    Each signal represents a single anomalous row from exchsync.MESSAGE.
    The rule name is in evidence['rule'], row data in evidence['row'].
    """
    value = signal.observed_value
    rule = signal.evidence.get("rule", "")
    row = signal.evidence.get("row", {})
    total = signal.evidence.get("total_rows", 0)

    # Query error
    if signal.evidence.get("error"):
        return Detection(
            incident_id=next_incident_id(),
            check_id=signal.check_id,
            application=Application.ATE,
            result=DetectionResult.FAIL,
            rule_name="ate_query_error",
            evidence=f"Query failed: {signal.evidence['error']}",
            proposed_severity=Severity.P2,
        )

    if value is None:
        return None

    # No anomaly
    if int(value) == 0:
        return Detection(
            incident_id="",
            check_id=signal.check_id,
            application=Application.ATE,
            result=DetectionResult.PASS,
            rule_name=f"{signal.check_id}_ok",
            evidence="No anomalies detected",
        )

    # Trade stuck
    if rule == "ate_trade_stuck":
        return Detection(
            incident_id=next_incident_id(),
            check_id=signal.check_id,
            application=Application.ATE,
            result=DetectionResult.FAIL,
            rule_name="ate_trade_stuck",
            evidence=(
                f"Trade stuck (synchstate=1, stale >10 min). "
                f"id={row.get('id')}, exchange={row.get('exchange')}, "
                f"lastupdated={row.get('lastupdated')}, "
                f"messageid={row.get('messageid')}. "
                # f"Total stuck: {total}"
            ),
            proposed_severity=Severity.P2,
        )

    # Trade failed
    if rule == "ate_trade_failed":
        return Detection(
            incident_id=next_incident_id(),
            check_id=signal.check_id,
            application=Application.ATE,
            result=DetectionResult.FAIL,
            rule_name="ate_trade_failed",
            evidence=(
                f"Trade failed (synchstate=5). "
                f"id={row.get('id')}, exchange={row.get('exchange')}, "
                f"failedreason={row.get('failedreason')}, "
                f"messageid={row.get('messageid')}. "
                # f"Total failed: {total}"
            ),
            proposed_severity=Severity.P2,
        )

    # Retry exhaustion
    if rule == "ate_retry_exhaustion":
        return Detection(
            incident_id=next_incident_id(),
            check_id=signal.check_id,
            application=Application.ATE,
            result=DetectionResult.FAIL,
            rule_name="ate_retry_exhaustion",
            evidence=(
                f"Retry exhaustion (synchstate=5, synchcount>=5). "
                f"id={row.get('id')}, exchange={row.get('exchange')}, "
                f"synchcount={row.get('synchcount')}, "
                f"failedreason={row.get('failedreason')}, "
                f"messageid={row.get('messageid')}. "
                # f"Total exhausted: {total}"
            ),
            proposed_severity=Severity.P1,
        )

    # Fallback pass
    return Detection(
        incident_id="",
        check_id=signal.check_id,
        application=Application.ATE,
        result=DetectionResult.PASS,
        rule_name=f"{signal.check_id}_ok",
        evidence=f"Value={value} within acceptable range",
    )


def _detect_promptopt(signal: NormalizedSignal) -> Detection | None:
    """PromptOpt: Activity staleness, queue depth, error count."""
    cfg = get_config().thresholds
    value = signal.observed_value

    # Query error
    if signal.evidence.get("error"):
        return Detection(
            incident_id=next_incident_id(),
            check_id=signal.check_id,
            application=Application.PROMPTOPT,
            result=DetectionResult.FAIL,
            rule_name="promptopt_query_error",
            evidence=f"Query failed: {signal.evidence['error']}",
            proposed_severity=Severity.P2,
        )

    if value is None:
        return None

    # Queue depth
    if signal.check_id == "promptopt_queue_depth":
        depth = int(value)
        if depth >= cfg.promptopt_queue_critical:
            return Detection(
                incident_id=next_incident_id(),
                check_id=signal.check_id,
                application=Application.PROMPTOPT,
                result=DetectionResult.FAIL,
                rule_name="promptopt_queue_critical",
                evidence=f"Queue depth={depth} exceeds critical threshold={cfg.promptopt_queue_critical}",
                proposed_severity=Severity.P1,
            )
        if depth >= cfg.promptopt_queue_warning:
            return Detection(
                incident_id=next_incident_id(),
                check_id=signal.check_id,
                application=Application.PROMPTOPT,
                result=DetectionResult.WARNING,
                rule_name="promptopt_queue_warning",
                evidence=f"Queue depth={depth} exceeds warning threshold={cfg.promptopt_queue_warning}",
                proposed_severity=Severity.P3,
            )

    # Error count
    if signal.check_id == "promptopt_errors" and int(value) > 0:
        return Detection(
            incident_id=next_incident_id(),
            check_id=signal.check_id,
            application=Application.PROMPTOPT,
            result=DetectionResult.FAIL,
            rule_name="promptopt_recent_errors",
            evidence=f"Found {value} errors in last 30 minutes",
            proposed_severity=Severity.P3,
        )

    # Pass
    return Detection(
        incident_id="",
        check_id=signal.check_id,
        application=Application.PROMPTOPT,
        result=DetectionResult.PASS,
        rule_name=f"{signal.check_id}_ok",
        evidence=f"Value={value} within acceptable range",
    )


# ── LLM-based detection ───────────────────────────────────────────────────────

_RESULT_MAP = {
    "FAIL": DetectionResult.FAIL,
    "WARNING": DetectionResult.WARNING,
    "PASS": DetectionResult.PASS,
}

_SEVERITY_MAP = {
    "P1": Severity.P1,
    "P2": Severity.P2,
    "P3": Severity.P3,
    "P4": Severity.P4,
}


def run_llm_detection(signals: list[NormalizedSignal], llm, rag_context: str = "") -> list[Detection]:
    """Use LLM to classify signals as FAIL/WARNING/PASS based on rules in the prompt.

    Returns only triggered detections (FAIL or WARNING).
    """
    if not signals:
        return []

    cfg = get_config().thresholds

    # Build signals JSON for the prompt
    signals_data = []
    for s in signals:
        entry = {
            "check_id": s.check_id,
            "application": s.application.value,
            "observed_value": s.observed_value,
            "expected_value": str(s.expected_value) if s.expected_value else None,
            "signal_type": s.signal_type.value,
            "error": s.evidence.get("error"),
            "source_table": s.evidence.get("source_table", ""),
        }
        # ATE signals carry row-level context
        if s.evidence.get("rule"):
            entry["rule"] = s.evidence["rule"]
        if s.evidence.get("row"):
            entry["row"] = s.evidence["row"]
        if s.evidence.get("total_rows"):
            entry["total_rows"] = s.evidence["total_rows"]
        signals_data.append(entry)

    user_content = LLM_DETECTION_USER.format(
        today=date.today().isoformat(),
        promptopt_queue_critical=cfg.promptopt_queue_critical,
        promptopt_queue_warning=cfg.promptopt_queue_warning,
        signals_json=json.dumps(signals_data, indent=2),
        rag_context=rag_context if rag_context else "No historical context available.",
    )

    messages = [
        SystemMessage(content=LLM_DETECTION_SYSTEM),
        HumanMessage(content=user_content),
    ]

    response = llm.invoke(messages)
    raw_output = response.content.strip()

    # Strip markdown fences if present
    if raw_output.startswith("```"):
        raw_output = raw_output.split("\n", 1)[1] if "\n" in raw_output else raw_output[3:]
        if raw_output.endswith("```"):
            raw_output = raw_output[:-3].strip()

    llm_results = json.loads(raw_output)

    detections: list[Detection] = []
    for item in llm_results:
        result = _RESULT_MAP.get(item.get("result", "").upper())
        if result is None or result == DetectionResult.PASS:
            continue

        severity = _SEVERITY_MAP.get(item.get("proposed_severity")) if item.get("proposed_severity") else None

        det = Detection(
            incident_id=next_incident_id(),
            check_id=item["check_id"],
            application=Application(item["application"]),
            result=result,
            rule_name=item.get("rule_name", item["check_id"]),
            confidence=item.get("confidence", "high"),
            evidence=item.get("evidence", ""),
            proposed_severity=severity,
        )
        detections.append(det)
        logger.info(f"LLM detection triggered: {det.rule_name} -> {det.result} (confidence: {det.confidence})")

    logger.info(f"LLM detection complete: {len(detections)} anomalies from {len(signals)} signals")
    return detections


# ── Public API ────────────────────────────────────────────────────────────────

def run_detection(signals: list[NormalizedSignal]) -> list[Detection]:
    """Run detection rules on all normalized signals.

    Returns only triggered detections (FAIL or WARNING).
    """
    detections: list[Detection] = []

    dispatch = {
        Application.ASCM: _detect_ascm,
        Application.ATE: _detect_ate,
        Application.PROMPTOPT: _detect_promptopt,
    }

    for signal in signals:
        fn = dispatch.get(signal.application)
        if fn is None:
            continue

        det = fn(signal)
        if det and det.result != DetectionResult.PASS:
            detections.append(det)
            logger.info(f"Detection triggered: {det.rule_name} -> {det.result}")

    logger.info(f"Detection complete: {len(detections)} anomalies from {len(signals)} signals")
    return detections


# ── LLM helper ───────────────────────────────────────────────────────────────

def build_explanation_prompt(det: Detection, signal: NormalizedSignal, rag_context: str = "") -> list:
    """Build multi-message prompt for LLM to explain a detection.

    Returns a list of LangChain messages:
      [SystemMessage, HumanMessage (developer instruction), HumanMessage (user data)]
    """
    # Build additional evidence from signal (row data for ATE, etc.)
    additional_parts = []
    if signal.evidence.get("row"):
        additional_parts.append(f"Row data: {json.dumps(signal.evidence['row'])}")
    if signal.evidence.get("total_rows"):
        additional_parts.append(f"Total affected rows: {signal.evidence['total_rows']}")
    if signal.evidence.get("rule"):
        additional_parts.append(f"Rule: {signal.evidence['rule']}")
    additional_evidence = "\n".join(additional_parts) if additional_parts else "N/A"

    user_content = DETECTION_USER.format(
        application=det.application.value,
        check_id=det.check_id,
        rule_name=det.rule_name,
        source_table=signal.evidence.get("source_table", "unknown"),
        observed_value=signal.observed_value,
        expected_value=signal.expected_value,
        business_date=signal.business_date.isoformat(),
        result=det.result.value,
        severity=det.proposed_severity.value if det.proposed_severity else "NONE",
        enrichment_context=signal.enrichment.get("interpretation", "No enrichment available."),
        additional_evidence=additional_evidence,
        rag_context=rag_context if rag_context else "No relevant application logs available.",
    )
    return [
        SystemMessage(content=DETECTION_SYSTEM),
        HumanMessage(content=DETECTION_DEVELOPER),
        HumanMessage(content=user_content),
    ]



# ── Step 3B: Soft Anomaly Discovery ──────────────────────────────────────────

def _collect_pass_signals(signals: list[NormalizedSignal]) -> list[NormalizedSignal]:
    """Run detection rules and return only PASS signals (those that didn't trigger)."""
    dispatch = {
        Application.ASCM: _detect_ascm,
        Application.ATE: _detect_ate,
        Application.PROMPTOPT: _detect_promptopt,
    }
    pass_signals = []
    for signal in signals:
        fn = dispatch.get(signal.application)
        if fn is None:
            continue
        det = fn(signal)
        if det and det.result == DetectionResult.PASS:
            pass_signals.append(signal)
        elif det is None:
            pass_signals.append(signal)
    return pass_signals


def run_soft_anomaly_detection(
    signals: list[NormalizedSignal],
    llm,
    baselines: dict,
    rag_context: str = "",
) -> list[dict]:
    """Step 3B: Use LLM to discover subtle anomalies in PASS signals.

    Takes signals that passed all deterministic rules and compares them
    against historical baselines to find unusual-but-not-failing patterns.

    Returns list of soft anomaly dicts (may be empty if nothing unusual).
    """
    from observer_advisor.prompts.soft_anomaly_prompts import (
        SOFT_ANOMALY_SYSTEM,
        SOFT_ANOMALY_USER,
    )
    from datetime import datetime
    import pytz

    pass_signals = _collect_pass_signals(signals)
    if not pass_signals:
        logger.info("Step 3B: No PASS signals to analyse for soft anomalies")
        return []

    now_utc = datetime.utcnow()
    try:
        now_uk = now_utc.replace(tzinfo=pytz.utc).astimezone(pytz.timezone("Europe/London"))
    except Exception:
        now_uk = now_utc

    # Build pass signals JSON
    pass_data = []
    for s in pass_signals:
        entry = {
            "check_id": s.check_id,
            "application": s.application.value,
            "observed_value": s.observed_value,
            "expected_value": str(s.expected_value) if s.expected_value else None,
            "signal_type": s.signal_type.value,
            "source_table": s.evidence.get("source_table", ""),
            "enrichment": s.enrichment,
        }
        pass_data.append(entry)

    # Extract baselines for the check_ids present
    baseline_entries = baselines.get("baselines", {})
    relevant_baselines = {}
    for s in pass_signals:
        base_check = s.check_id.split("_ok")[0]  # strip _ok suffix if present
        if base_check in baseline_entries:
            relevant_baselines[base_check] = baseline_entries[base_check]

    cross_patterns = baselines.get("cross_signal_patterns", [])

    user_content = SOFT_ANOMALY_USER.format(
        today=date.today().isoformat(),
        time_utc=now_utc.strftime("%H:%M:%S"),
        time_uk=now_uk.strftime("%H:%M:%S"),
        day_of_week=now_utc.strftime("%A"),
        pass_signals_json=json.dumps(pass_data, indent=2, default=str),
        baselines_json=json.dumps(relevant_baselines, indent=2),
        cross_signal_json=json.dumps(cross_patterns, indent=2),
        rag_context=rag_context if rag_context else "No historical context available.",
    )

    messages = [
        SystemMessage(content=SOFT_ANOMALY_SYSTEM),
        HumanMessage(content=user_content),
    ]

    try:
        response = llm.invoke(messages)
        raw_output = response.content.strip()

        # Strip markdown fences if present
        if raw_output.startswith("```"):
            raw_output = raw_output.split("\n", 1)[1] if "\n" in raw_output else raw_output[3:]
            if raw_output.endswith("```"):
                raw_output = raw_output[:-3].strip()

        findings = json.loads(raw_output)
        if not isinstance(findings, list):
            findings = []

        # Attach LLM I/O for traceability
        prompt_text = "\n---\n".join(m.content for m in messages)
        for f in findings:
            f["llm_input"] = prompt_text
            f["llm_output"] = response.content.strip()

        logger.info(f"Step 3B: {len(findings)} soft anomalies found from {len(pass_signals)} PASS signals")
        return findings

    except Exception as e:
        logger.warning(f"Step 3B: Soft anomaly detection failed: {e}")
        return []
