"""Step 3A: Detection Validation (Hybrid).

Validates Step 3 detections against business context before they flow
to Step 4 (Correlation).

Hybrid approach:
  1. Deterministic checks (fast, free, reliable):
     - Maintenance window → auto-SUPPRESS
     - UK holiday → auto-DOWNGRADE
     - Outside business hours → auto-DOWNGRADE
     - Exact false-positive pattern match → auto-SUPPRESS or DOWNGRADE
  2. LLM validation (nuanced, for surviving detections):
     - Sends detection + all business context to LLM
     - LLM decides KEEP / SUPPRESS / DOWNGRADE with reason

Input:  list of detection dicts from Step 3
Output: list of validated detection dicts (suppressed ones removed,
        severity adjusted, validation metadata attached)
"""

from __future__ import annotations

import json
import logging
import re
from datetime import datetime, date, time
from pathlib import Path
from typing import Any

from zoneinfo import ZoneInfo

logger = logging.getLogger(__name__)

# ── Config directory ──────────────────────────────────────────────────────────

_CONFIG_DIR = Path(__file__).resolve().parent.parent / "config"


# ── Load business context files ──────────────────────────────────────────────

def _load_json(filename: str) -> dict:
    path = _CONFIG_DIR / filename
    if not path.exists():
        logger.warning(f"Config file not found: {path}")
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_business_hours() -> dict:
    return _load_json("business_hours.json")


def load_holidays() -> dict:
    return _load_json("uk_holidays.json")


def load_maintenance_windows() -> dict:
    return _load_json("maintenance_windows.json")


def load_false_positive_patterns() -> dict:
    return _load_json("false_positive_patterns.json")


# ── Time helpers ─────────────────────────────────────────────────────────────

def _now_uk() -> datetime:
    return datetime.now(ZoneInfo("Europe/London"))


def _parse_time(t: str) -> time:
    parts = t.split(":")
    return time(int(parts[0]), int(parts[1]))


def _time_in_range(t: time, start: time, end: time) -> bool:
    """Check if time t is in [start, end). Handles overnight ranges."""
    if start <= end:
        return start <= t < end
    else:
        return t >= start or t < end


# ── Deterministic checks ─────────────────────────────────────────────────────

def check_maintenance_window(
    detection: dict, now_utc: datetime, maint_config: dict
) -> dict | None:
    """Check if detection falls within a scheduled maintenance window.
    Returns validation result dict if matched, None otherwise.
    """
    app = detection.get("application", "").upper()
    windows = maint_config.get("maintenance_windows", [])

    day_name = now_utc.strftime("%A")
    current_time = now_utc.time()

    for window in windows:
        if window.get("application", "").upper() != app:
            continue
        schedule = window.get("schedule", {})
        if schedule.get("day_of_week", "").lower() != day_name.lower():
            continue
        start = _parse_time(schedule.get("start_utc", "00:00"))
        end = _parse_time(schedule.get("end_utc", "23:59"))
        if _time_in_range(current_time, start, end):
            return {
                "check": "maintenance_window",
                "action": "SUPPRESS",
                "reason": f"Maintenance window active: {window.get('description', '')} "
                          f"({schedule.get('day_of_week')} {schedule.get('start_utc')}-{schedule.get('end_utc')} UTC)",
                "matched_window": window.get("description", ""),
            }
    return None


def check_holiday(
    detection: dict, today: date, holiday_config: dict
) -> dict | None:
    """Check if today is a UK bank holiday.
    Returns validation result dict if matched, None otherwise.
    """
    holidays = holiday_config.get("holidays", [])
    today_str = today.isoformat()

    for h in holidays:
        if h.get("date") == today_str:
            return {
                "check": "holiday",
                "action": "SUPPRESS",
                # "adjusted_severity": "P4",
                "reason": f"UK bank holiday: {h.get('name', '')} — reduced activity expected",
                "holiday_name": h.get("name", ""),
            }
    return None


def check_business_hours(
    detection: dict, now_uk: datetime, bh_config: dict
) -> dict | None:
    """Check if detection is outside business hours.
    Returns validation result dict if matched, None otherwise.
    """
    app = detection.get("application", "").upper()
    apps = bh_config.get("applications", {})
    app_config = apps.get(app)
    if not app_config:
        return None

    bh = app_config.get("business_hours", {})
    start = _parse_time(bh.get("start", "00:00"))
    end = _parse_time(bh.get("end", "23:59"))
    biz_days = [d.lower() for d in app_config.get("business_days", [])]

    current_day = now_uk.strftime("%A").lower()
    current_time = now_uk.time()

    if current_day not in biz_days:
        return {
            "check": "business_hours",
            "action": "DOWNGRADE",
            "adjusted_severity": "P3",
            "reason": f"Outside business days for {app} (today is {now_uk.strftime('%A')})",
        }

    if not _time_in_range(current_time, start, end):
        return {
            "check": "business_hours",
            "action": "DOWNGRADE",
            "adjusted_severity": "P3",
            "reason": (
                f"Outside business hours for {app} "
                f"(current: {now_uk.strftime('%H:%M')} UK, "
                f"hours: {bh.get('start')}-{bh.get('end')})"
            ),
        }

    return None


def check_false_positive(
    detection: dict, now_uk: datetime, fp_config: dict
) -> dict | None:
    """Check if detection matches a known false positive pattern.
    Returns validation result dict if matched, None otherwise.
    """
    rule_name = detection.get("rule_name", "")
    evidence = detection.get("evidence", "")
    patterns = fp_config.get("patterns", [])

    for pat in patterns:
        if pat.get("rule_name") != rule_name:
            continue

        conditions = pat.get("conditions", {})
        matched = True

        # Check exchange
        if "exchange" in conditions:
            if conditions["exchange"].lower() not in evidence.lower():
                matched = False

        # Check time range
        if matched and "time_range" in conditions:
            tr = conditions["time_range"]
            tz_name = conditions.get("timezone", "Europe/London")
            check_time = now_uk.time() if tz_name == "Europe/London" else datetime.now(ZoneInfo(tz_name)).time()
            after = _parse_time(tr.get("after", "00:00"))
            before = _parse_time(tr.get("before", "23:59"))
            if not _time_in_range(check_time, after, before):
                matched = False

        # Check day of week
        if matched and "day_of_week" in conditions:
            allowed_days = [d.lower() for d in conditions["day_of_week"]]
            if now_uk.strftime("%A").lower() not in allowed_days:
                matched = False

        # Check failedreason contains
        if matched and "failedreason_contains" in conditions:
            if conditions["failedreason_contains"].lower() not in evidence.lower():
                matched = False

        if matched:
            action = pat.get("action", "SUPPRESS")
            result = {
                "check": "false_positive",
                "action": action,
                "reason": pat.get("reason", "Matches known false positive pattern"),
                "pattern_id": pat.get("id", ""),
                "confidence": pat.get("confidence", 0.5),
            }
            if action == "DOWNGRADE":
                result["adjusted_severity"] = pat.get("downgrade_to", "P3")
            return result

    return None


# ── Deterministic validation (Phase 1) ───────────────────────────────────────

def run_deterministic_checks(detection: dict) -> list[dict]:
    """Run all deterministic checks against a single detection.
    Returns list of validation results (one per triggered check).
    """
    now_utc = datetime.now(ZoneInfo("UTC"))
    now_uk = _now_uk()
    today = now_uk.date()

    bh_config = load_business_hours()
    holiday_config = load_holidays()
    maint_config = load_maintenance_windows()
    fp_config = load_false_positive_patterns()

    results = []

    # 1. Maintenance window (highest priority — always suppress)
    maint = check_maintenance_window(detection, now_utc, maint_config)
    if maint:
        results.append(maint)
        return results  # No need to check further

    # 2. Holiday
    holiday = check_holiday(detection, today, holiday_config)
    if holiday:
        results.append(holiday)

    # 3. Business hours
    bh = check_business_hours(detection, now_uk, bh_config)
    if bh:
        results.append(bh)

    # 4. False positive pattern
    fp = check_false_positive(detection, now_uk, fp_config)
    if fp:
        results.append(fp)

    return results


# ── LLM validation (Phase 2) ─────────────────────────────────────────────────

def build_validation_prompt(detection: dict, deterministic_results: list[dict]) -> str:
    """Build the user prompt for LLM validation."""
    from observer_advisor.prompts.validator_prompts import VALIDATOR_USER

    now_utc = datetime.now(ZoneInfo("UTC"))
    now_uk = _now_uk()
    today = now_uk.date()

    app = detection.get("application", "").upper()
    bh_config = load_business_hours()
    holiday_config = load_holidays()
    maint_config = load_maintenance_windows()
    fp_config = load_false_positive_patterns()

    # Business hours info
    app_bh = bh_config.get("applications", {}).get(app, {})
    bh_info = "Not configured"
    if app_bh:
        bh = app_bh.get("business_hours", {})
        bh_info = (
            f"  {bh.get('start', '?')} - {bh.get('end', '?')} UK time, "
            f"  Days: {', '.join(app_bh.get('business_days', []))}"
        )

    # Maintenance info
    maint_info_parts = []
    for w in maint_config.get("maintenance_windows", []):
        if w.get("application", "").upper() == app:
            s = w.get("schedule", {})
            maint_info_parts.append(
                f"  - {w.get('description', '?')}: {s.get('day_of_week')} "
                f"{s.get('start_utc')}-{s.get('end_utc')} UTC"
            )
    maint_info = "\n".join(maint_info_parts) if maint_info_parts else "  None scheduled"

    # Holiday info
    is_holiday = False
    holiday_name = ""
    for h in holiday_config.get("holidays", []):
        if h.get("date") == today.isoformat():
            is_holiday = True
            holiday_name = f"({h.get('name', '')})"
            break

    # False positive info
    fp_info_parts = []
    for p in fp_config.get("patterns", []):
        if p.get("rule_name") == detection.get("rule_name"):
            fp_info_parts.append(
                f"  - [{p.get('id')}] {p.get('reason', '?')} "
                f"(confidence: {p.get('confidence', '?')})"
            )
    fp_info = "\n".join(fp_info_parts) if fp_info_parts else "  No matching patterns"

    # Feedback info (deterministic results as context)
    det_summary_parts = []
    for dr in deterministic_results:
        det_summary_parts.append(
            f"  - Deterministic check '{dr.get('check')}': "
            f"{dr.get('action')} — {dr.get('reason', '')}"
        )
    feedback_info = "\n".join(det_summary_parts) if det_summary_parts else "  No deterministic flags raised"

    return VALIDATOR_USER.format(
        rule_name=detection.get("rule_name", "?"),
        application=app,
        severity=detection.get("proposed_severity", "?"),
        result=detection.get("result", "?"),
        evidence=detection.get("evidence", ""),
        detection_time=detection.get("detection_time", now_utc.isoformat()),
        current_time_utc=now_utc.strftime("%Y-%m-%d %H:%M:%S"),
        current_time_uk=now_uk.strftime("%Y-%m-%d %H:%M:%S"),
        day_of_week=now_uk.strftime("%A"),
        is_holiday="Yes" if is_holiday else "No",
        holiday_name=holiday_name,
        business_hours_info=bh_info,
        maintenance_info=maint_info,
        false_positive_info=fp_info,
        feedback_info=feedback_info,
    )


def run_llm_validation(detection: dict, deterministic_results: list[dict], llm) -> dict:
    """Send detection to LLM for nuanced validation.
    Returns validation result dict.
    """
    from langchain_core.messages import HumanMessage, SystemMessage
    from observer_advisor.prompts.validator_prompts import VALIDATOR_SYSTEM

    user_content = build_validation_prompt(detection, deterministic_results)
    messages = [
        SystemMessage(content=VALIDATOR_SYSTEM),
        HumanMessage(content=user_content),
    ]

    response = llm.invoke(messages)
    raw_output = response.content.strip()

    # Strip markdown fences if present
    if raw_output.startswith("```"):
        raw_output = raw_output.split("\n", 1)[1] if "\n" in raw_output else raw_output[3:]
        if raw_output.endswith("```"):
            raw_output = raw_output[:-3].strip()

    try:
        llm_result = json.loads(raw_output)
    except json.JSONDecodeError:
        logger.warning(f"Failed to parse LLM validation response: {raw_output[:200]}")
        llm_result = {
            "action": "KEEP",
            "adjusted_severity": detection.get("proposed_severity", "P2"),
            "reason": "LLM response unparseable — keeping detection as-is",
            "confidence": 0.0,
        }

    return {
        "check": "llm_validation",
        "action": llm_result.get("action", "KEEP"),
        "adjusted_severity": llm_result.get("adjusted_severity"),
        "reason": llm_result.get("reason", ""),
        "confidence": llm_result.get("confidence", 0.5),
        "llm_input": user_content,
        "llm_output": raw_output,
    }


# ── Priority for severity: pick the most severe action ──────────────────────

_SEVERITY_RANK = {"P1": 1, "P2": 2, "P3": 3, "P4": 4}


def _resolve_validation(detection: dict, all_results: list[dict]) -> dict:
    """Combine deterministic + LLM results into final validation outcome.

    Priority:
      - Any SUPPRESS → suppress the detection
      - Any DOWNGRADE → use lowest-priority (highest P number) severity
      - Otherwise → KEEP with original severity
    """
    original_severity = detection.get("proposed_severity", "P2")
    suppressed = False
    action = "KEEP"
    reasons = []
    adjusted_severity = original_severity
    checks_fired = {}

    for r in all_results:
        check_name = r.get("check", "unknown")
        checks_fired[check_name] = {
            "action": r.get("action"),
            "reason": r.get("reason", ""),
        }

        if r.get("action") == "SUPPRESS":
            suppressed = True
            action = "SUPPRESS"
            reasons.append(r.get("reason", ""))
        elif r.get("action") == "DOWNGRADE":
            if action != "SUPPRESS":
                action = "DOWNGRADE"
            new_sev = r.get("adjusted_severity", adjusted_severity)
            if _SEVERITY_RANK.get(new_sev, 99) > _SEVERITY_RANK.get(adjusted_severity, 99):
                adjusted_severity = new_sev
            reasons.append(r.get("reason", ""))

    return {
        "original_severity": original_severity,
        "adjusted_severity": adjusted_severity if action == "DOWNGRADE" else original_severity,
        "action": action,
        "suppressed": suppressed,
        "reasons": reasons,
        "checks": checks_fired,
    }


# ── Main entry point ────────────────────────────────────────────────────────

def validate_detections(detections: list[dict], llm=None) -> list[dict]:
    """Run hybrid validation on all detections.

    Args:
        detections: List of detection dicts from Step 3.
        llm: LangChain LLM instance (if None, skip LLM phase).

    Returns:
        List of validated detection dicts. Suppressed detections are removed.
        Each surviving detection has a 'validation' field with metadata.
    """
    validated = []

    for det in detections:
        rule_name = det.get("rule_name", "?")
        logger.info(f"  Validating detection: {rule_name} ({det.get('check_id', '?')})")

        # Phase 1: Deterministic checks
        det_results = run_deterministic_checks(det)

        # If deterministic says SUPPRESS, skip LLM
        is_suppressed = any(r.get("action") == "SUPPRESS" for r in det_results)

        # Phase 2: LLM validation (only if not already suppressed and LLM is available)
        if not is_suppressed and llm is not None:
            try:
                llm_result = run_llm_validation(det, det_results, llm)
                det_results.append(llm_result)
                # Store LLM I/O for traceability
                det["validation_llm_input"] = llm_result.get("llm_input")
                det["validation_llm_output"] = llm_result.get("llm_output")
            except Exception as e:
                logger.warning(f"LLM validation failed for {rule_name}: {e}")

        # Resolve final validation outcome
        validation = _resolve_validation(det, det_results)

        if validation["suppressed"]:
            logger.info(
                f"  SUPPRESSED: {rule_name} — {'; '.join(validation['reasons'])}"
            )
            # Still include in output but marked as suppressed (for UI display)
            det["validation"] = validation
            det["validation"]["included"] = False
            validated.append(det)
            continue

        # Apply severity adjustment
        if validation["action"] == "DOWNGRADE":
            logger.info(
                f"  DOWNGRADED: {rule_name} "
                f"{validation['original_severity']} → {validation['adjusted_severity']} "
                f"— {'; '.join(validation['reasons'])}"
            )
            det["proposed_severity"] = validation["adjusted_severity"]

        det["validation"] = validation
        det["validation"]["included"] = True
        validated.append(det)

    # Log summary
    total = len(detections)
    suppressed_count = sum(1 for d in validated if not d.get("validation", {}).get("included", True))
    kept = total - suppressed_count
    logger.info(f"  Validation complete: {total} detections → {kept} kept, {suppressed_count} suppressed")

    return validated
