# """
# Observer Agent - Streamlit Dashboard
# =====================================
# Visualises every pipeline step with Before-LLM / After-LLM comparison.
# Filter by application (ASCM, ATE, PromptOpt) via sidebar radio buttons.

# Run:  streamlit run observer_advisor/streamlit_app.py
# """

# from __future__ import annotations

# import sys
# from pathlib import Path
# import os

# import streamlit as st

# # Ensure parent is on sys.path so imports work when run via `streamlit run`
# _parent = str(Path(__file__).resolve().parent.parent)
# if _parent not in sys.path:
#     sys.path.insert(0, _parent)

# from dotenv import load_dotenv
# load_dotenv(dotenv_path=Path(__file__).resolve().parent / ".env")

# from observer_advisor.logging_config import setup_logging
# setup_logging()

# from observer_advisor.scheduler import (
#     start_scheduler, stop_scheduler, is_running, get_job_status,
# )
# from observer_advisor.steps.db_persistence import (
#     get_observations, update_feedback, get_step_outputs,
# )
# from observer_advisor.tools.azure_rag import store_feedback as rag_store_feedback
# from observer_advisor.tools.azure_rag import store_feedback as rag_store_feedback


# # ── Helpers ───────────────────────────────────────────────────────────────────

# def severity_colour(sev: str) -> str:
#     return {
#         "P1": "#FF4B4B",
#         "P2": "#FF8C00",
#         "P3": "#FFD700",
#         "P4": "#4DA6FF",
#     }.get(sev, "#888888")


# def severity_emoji(sev: str) -> str:
#     return {"P1": "🔴", "P2": "🟠", "P3": "🟡", "P4": "🔵"}.get(sev, "⚪")


# def result_colour(result: str) -> str:
#     return {"FAIL": "#FF4B4B", "WARNING": "#FFD700", "PASS": "#00C853"}.get(result, "#888")


# def result_emoji(result: str) -> str:
#     return {"FAIL": "🔴", "WARNING": "🟡", "PASS": "🟢"}.get(result, "⚪")


# # ── Page config ───────────────────────────────────────────────────────────────

# st.set_page_config(
#     page_title="Observer Agent Dashboard",
#     page_icon="🔭",
#     layout="wide",
#     initial_sidebar_state="expanded",
# )

# # Custom CSS
# st.markdown("""
# <style>
#     .main-header {
#         font-size: 2rem; font-weight: 700; color: #1E88E5;
#         border-bottom: 3px solid #1E88E5; padding-bottom: 0.3rem;
#         margin-bottom: 1rem;
#     }
#     .step-header {
#         font-size: 1.3rem; font-weight: 600; color: #333;
#         border-left: 4px solid #1E88E5; padding-left: 0.8rem;
#         margin: 1.5rem 0 0.8rem 0;
#     }
#     .metric-card {
#         background: #f8f9fa; border-radius: 8px; padding: 1rem 1.2rem;
#         border: 1px solid #dee2e6; text-align: center;
#     }
#     .metric-value { font-size: 2rem; font-weight: 700; color: #1E88E5; }
#     .metric-label { font-size: 0.85rem; color: #666; margin-top: 0.2rem; }
#     .llm-box {
#         background: #FFF8E1; border: 1px solid #FFD54F; border-radius: 6px;
#         padding: 0.8rem 1rem; margin: 0.5rem 0; font-size: 0.85rem;
#     }
#     .no-llm-box {
#         background: #FFEBEE; border: 1px solid #EF9A9A; border-radius: 6px;
#         padding: 0.8rem 1rem; margin: 0.5rem 0; font-size: 0.85rem;
#         color: #C62828;
#     }
#     .before-box {
#         background: #F3E5F5; border: 1px solid #CE93D8; border-radius: 6px;
#         padding: 0.8rem 1rem; font-size: 0.85rem;
#     }
#     .after-box {
#         background: #E8F5E9; border: 1px solid #A5D6A7; border-radius: 6px;
#         padding: 0.8rem 1rem; font-size: 0.85rem;
#     }
#     div[data-testid="stExpander"] { border: 1px solid #e0e0e0; border-radius: 8px; margin-bottom: 0.5rem; }
#     div[data-testid="stExpander"] [data-testid="stMetricValue"] { font-size: 0.9rem; font-weight: 700; }
#     div[data-testid="stExpander"] [data-testid="stMetricLabel"] { font-size: 0.7rem; }
# </style>
# """, unsafe_allow_html=True)


# # ── Sidebar ───────────────────────────────────────────────────────────────────

# with st.sidebar:
#     st.markdown("## Observer Agent")
#     st.divider()

#     selected_app = st.radio(
#         "Application",
#         ["All", "ASCM", "ATE", "PromptOpt"],
#         index=0,
#     )

#     st.divider()

#     # ── Scheduler controls ──
#     st.markdown("### Scheduler")

#     if is_running():
#         st.success("Running",)
#         if st.button("Stop Scheduler"):
#             stop_scheduler()
#             st.rerun()

#         # Show job schedule
#         jobs = get_job_status()
#         for job in jobs:
#             st.caption(f"**{job['name']}** — next: {job['next_run']}  |  last: {job['last_run']}")
#     else:
#         st.warning("Stopped", )
#         if st.button("Start Scheduler", type="primary"):
#             start_scheduler()
#             st.rerun()

#     st.divider()

#     # ── Run Pipeline button (manual) ──
#     st.markdown("### Manual")
#     if st.button("Run Pipeline Now"):
#         with st.spinner("Running Observer pipeline…"):
#             import subprocess, sys
#             proc = subprocess.run(
#                 [sys.executable, "-m", "observer_advisor.main"],
#                 cwd=str(Path(__file__).resolve().parent.parent),
#                 capture_output=True,
#                 text=True,
#                 timeout=120,
#             )
#         if proc.returncode == 0:
#             st.success("Pipeline finished! Refreshing…")
#             st.cache_data.clear()
#             st.rerun()
#         else:
#             st.error("Pipeline failed!")
#             st.code(proc.stderr or proc.stdout, language="text")

#     if st.button("Refresh Data", use_container_width=True):
#         st.cache_data.clear()
#         st.rerun()

#     # Auto-refresh toggle (when scheduler is running)
#     auto_refresh = st.checkbox("Auto-refresh (60s)", value=is_running())
#     if auto_refresh:
#         st.caption("Dashboard refreshes every 60 seconds.")

#     st.caption("Reads JSON files from `outputs/` folder.")


# # ── Auto-refresh (stdlib, no external package) ──────────────────────────────

# if auto_refresh:
#     # Use Streamlit's built-in auto-rerun via HTML meta refresh
#     st.markdown(
#         '<meta http-equiv="refresh" content="60">',
#         unsafe_allow_html=True,
#     )


# # ── Load data ─────────────────────────────────────────────────────────────────

# # Load observations from DB (used by tiles + incidents table)
# all_observations = get_observations(limit=200)

# run_ts = all_observations[0].get("timestamp", "—") if all_observations else "—"


# st.markdown('<div class="main-header">Observer Agent Dashboard</div>', unsafe_allow_html=True)
# st.markdown(f"**Last run:** `{run_ts}`")

# # Quick stats row — anomaly count per app from DB
# def _app_incident_count(app_name: str) -> int:
#     return len([o for o in all_observations if o.get("application", "").upper() == app_name.upper()])

# c1, c2, c3 = st.columns(3)
# for col, app_name in zip([c1, c2, c3], ["ASCM", "ATE", "PromptOpt"]):
#     cnt = _app_incident_count(app_name)
#     col.markdown(
#         f'<div class="metric-card">'
#         f'<div class="metric-value">{cnt}</div>'
#         f'<div class="metric-label">{app_name}</div>'
#         f'</div>',
#         unsafe_allow_html=True,
#     )


# # ═══════════════════════════════════════════════════════════════════════════════
# # INCIDENTS LIST + FEEDBACK
# # ═══════════════════════════════════════════════════════════════════════════════

# st.divider()
# st.markdown(
#     '<div class="step-header">  Incidents List</div>',
#     unsafe_allow_html=True,
# )

# observations = all_observations

# # Filter by selected app
# if selected_app != "All":
#     observations = [o for o in observations if o.get("application", "").upper() == selected_app.upper()]

# if not observations:
#     st.info("No observations in the database yet.")
# else:
#     import pandas as pd

#     # Pagination
#     PAGE_SIZE = 10
#     if "page" not in st.session_state:
#         st.session_state.page = 0

#     total_pages = max(1, (len(observations) + PAGE_SIZE - 1) // PAGE_SIZE)
#     # Clamp page to valid range
#     if st.session_state.page >= total_pages:
#         st.session_state.page = total_pages - 1

#     start_idx = st.session_state.page * PAGE_SIZE
#     end_idx = start_idx + PAGE_SIZE
#     page_observations = observations[start_idx:end_idx]
    
#     # Build table data
#     # Display-friendly rule names
#     RULE_DISPLAY_NAMES = {
#         "ascm_tgt_frequency": "ASCM Target Frequency",
#         "ascm_fr": "ASCM FR",
#         "ascm_avg_frequency": "ASCM Avg Frequency",
#         "ascm_adjusted_pn": "ASCM Adjusted PN",
#     }
    
#     table_data = []
#     for obs_item in page_observations:
#         # Format timestamp as "date time" (drop timezone/fractional seconds)
#         raw_ts = obs_item.get("timestamp", "")
#         if raw_ts:
#             try:
#                 from datetime import datetime as _dt
#                 dt = _dt.fromisoformat(str(raw_ts))
#                 fmt_ts = dt.strftime("%Y-%m-%d %H:%M:%S")
#             except (ValueError, TypeError):
#                 fmt_ts = str(raw_ts)
#         else:
#             fmt_ts = "—"
        
#         raw_rule = obs_item.get("rule_name", "?")
#         display_rule = RULE_DISPLAY_NAMES.get(raw_rule, raw_rule)
        
#         table_data.append({
#             "Application": obs_item.get("application", "?"),
#             "Incident ID": obs_item.get("incident_id", "—") or "—",
#             "Timestamp": fmt_ts,
#             "Rule": display_rule,
#             "Status": obs_item.get("status", "?"),
#         })

#     df = pd.DataFrame(table_data)

#     selection = st.dataframe(
#         df,
#         use_container_width=True,
#         hide_index=True,
#         on_select="rerun",
#         selection_mode="single-row",
#         key="incidents_table",
#     )
    
#     # Pagination controls
#     pcol1, pcol2, pcol3 = st.columns([1, 2, 1])
#     with pcol1:
#         if st.button("⬅ Previous", disabled=(st.session_state.page == 0)):
#             st.session_state.page -= 1
#             st.rerun()
#     with pcol2:
#         st.caption(f"Page {st.session_state.page + 1} of {total_pages}  ({len(observations)} total)")
#     with pcol3:
#         if st.button("Next ➡", disabled=(st.session_state.page >= total_pages - 1)):
#             st.session_state.page += 1
#             st.rerun()

#     # Detail view for selected observation
#     selected_rows = selection.selection.rows if selection.selection else []
#     obs = page_observations[selected_rows[0]] if selected_rows else None

#     if obs:
#         st.divider()

#         # Fetch all step outputs for this observation's pipeline run
#         run_id = obs.get("run_id")
#         app_name = obs.get("application", "")
#         obs_rule_name = obs.get("rule_name", "")
#         step_outputs = {}
#         if run_id:
#             for so in get_step_outputs(run_id, app_name):
#                 step_outputs[so["step_number"]] = so["step_output"]

#         # ── Determine check_id for filtering to the selected anomaly ──
#         obs_check_id = None
#         s3_all = step_outputs.get(3)
#         if s3_all:
#             dets_list = s3_all if isinstance(s3_all, list) else [s3_all]
#             for d in dets_list:
#                 if d.get("rule_name") == obs_rule_name:
#                     obs_check_id = d.get("check_id")
#                     break
#         # For NORMAL observations, rule_name IS the check_id
#         if not obs_check_id:
#             obs_check_id = obs_rule_name

#         # ── Step 1 — Raw Results ──
#         with st.expander("Step 1 — Raw Results (DB Queries)", expanded=False):
#             s1 = step_outputs.get(1)
#             if s1:
#                 items = s1 if isinstance(s1, list) else [s1]
#                 for item in items:
#                     app = item.get("application", "?")
#                     err = item.get("error")
#                     # icon = "🟢" if not err else "🔴"
#                     # st.markdown(f"{icon}  **{app}**")
#                     if "checks" in item:
#                         filtered_checks = {cid: cdata for cid, cdata in item["checks"].items()
#                                            if cid == obs_check_id} if obs_check_id else item["checks"]
                        
#                         # Show as table
#                         s1_table = []
#                         for cid, cdata in filtered_checks.items():
#                             display_cid = RULE_DISPLAY_NAMES.get(cid, cid)
#                             # # status = "✅" if not cdata.get("error") else "❌"
#                             # st.markdown(f"**{display_cid}**")
#                             # col1, col2 = st.columns(2)
#                             # col1.code(f"Source: {cdata.get('source_table', '—')}")
#                             # col2.code(f"Value:  {cdata.get('raw_value', 'null')}")
#                             # if cdata.get("error"):
#                             #     st.error(f"Error: {cdata['error']}")
                            
#                             s1_table.append({
#                                 "Rule": display_cid,
#                                 # "Status": status,
#                                 "Source Table": cdata.get("source_table", "—"),
#                                 "Value": str(cdata.get("raw_value", "null")),
#                                 "Error": cdata.get("error") or "—",
#                             })
#                         if s1_table:
#                             st.dataframe(
#                                 pd.DataFrame(s1_table),
#                                 use_container_width=True,
#                                 hide_index=True,
#                             )
#                     else:
#                         # col1, col2 = st.columns(2)
#                         # col1.code(f"Source: {item.get('source_table', '—')}")
#                         # col2.code(f"Value:  {item.get('raw_value', 'null')}")
#                         # if err:
#                         #     st.error(f"Error: {err}")
#                         s1_table = [{
#                             "Source Table": item.get("source_table", "—"),
#                             "Value": str(item.get("raw_value", "null")),
#                             "Error": err or "—",
#                         }]
#                         st.dataframe(
#                             pd.DataFrame(s1_table),
#                             use_container_width=True,
#                             hide_index=True,
#                         )
#                     st.markdown("---")
#             else:
#                 st.caption("No data")

#         # ── Step 2 — Signals ──
#         with st.expander("Step 2 — Normalized Signals (+ LLM Enrichment)", expanded=False):
#             s2 = step_outputs.get(2)
#             if s2:
#                 items = s2 if isinstance(s2, list) else [s2]
#                 if obs_check_id:
#                     items = [s for s in items if s.get("check_id") == obs_check_id]
#                 for sig in items:
#                     check = sig.get("check_id", "?")
#                     sig_app = sig.get("application", app_name).upper()
#                     sig_env = "Dev" if sig_app == "PROMPTOPT" else "Prod"
#                     display_check = RULE_DISPLAY_NAMES.get(check, check)
#                     # st.markdown(f"📡  **{display_check}**")
#                     cols = st.columns(3)
#                     cols[0].metric("Environment", sig_env)
#                     cols[1].metric("Application", sig_app)
#                     cols[2].metric("Rule", display_check)

#                     evidence = sig.get("evidence", {})
#                     st.markdown(
#                         f'<div class="before-box">'
#                         f'<b>Evidence (deterministic):</b><br>'
#                         f'Source Table: {evidence.get("source_table", "—")}<br>'
#                         f'Error: {evidence.get("error") or "None"}<br>'
#                         f'Query: {evidence.get("query", "—")}'
#                         f'</div>',
#                         unsafe_allow_html=True,
#                     )

#                     enrichment = sig.get("enrichment", {})
#                     interpretation = enrichment.get("interpretation") if isinstance(enrichment, dict) else None
#                     if interpretation:
#                         st.markdown(
#                             f'<div class="after-box">'
#                             f'<b>Interpretation:</b> {interpretation}'
#                             f'</div>',
#                             unsafe_allow_html=True,
#                         )

#                     llm_out = evidence.get("llm_output")
#                     if llm_out:
#                         with st.popover("🔍 LLM Response"):
#                             st.text(llm_out)
#                     st.markdown("---")
#             else:
#                 st.caption("No data")

#         # ── Step 3 — Detections (with RAG context) ──
#         with st.expander("Step 3 — Detections (Rules + LLM Explanation)", expanded=False):
#             s3 = step_outputs.get(3)
#             if s3:
#                 items = s3 if isinstance(s3, list) else [s3]
#                 if obs_rule_name:
#                     items = [d for d in items if d.get("rule_name") == obs_rule_name]
#                 for det in items:
#                     inc_id = det.get("incident_id", "?")
#                     rule = det.get("rule_name", "?")
#                     display_rule_det = RULE_DISPLAY_NAMES.get(rule, rule)
#                     result = det.get("result", "?")
#                     sev = det.get("proposed_severity", "—")
#                     # emoji = result_emoji(result)
#                     # st.markdown(f"{emoji}  **{inc_id}** — {display_rule_det}  [{result}]")

#                     det_app = det.get("application", app_name).upper()
#                     det_env = "Dev" if det_app == "PROMPTOPT" else "Prod"
#                     cols = st.columns(3)
#                     cols[0].metric("Environment", det_env)
#                     cols[1].metric("Application", det_app)
#                     cols[2].metric("Rule", display_rule_det)

#                     evidence_raw = det.get("evidence", "")
#                     if " | LLM: " in str(evidence_raw):
#                         before_part, after_part = str(evidence_raw).split(" | LLM: ", 1)
#                     else:
#                         before_part = evidence_raw
#                         after_part = None

#                     st.markdown(
#                         f'<div class="before-box"><b>Evidence:</b> {before_part}</div>',
#                         unsafe_allow_html=True,
#                     )

#                     rag_ctx = det.get("rag_context")
#                     if rag_ctx:
#                         with st.expander("Retrieved Incidents (RAG Context)", expanded=False):
#                             st.text(rag_ctx)

#                     if after_part:
#                         st.markdown(
#                             f'<div class="after-box"><b>LLM Explanation:</b> {after_part}</div>',
#                             unsafe_allow_html=True,
#                         )
#                     else:
#                         llm_out = det.get("llm_output")
#                         if llm_out:
#                             st.markdown(
#                                 f'<div class="after-box"><b>LLM Explanation:</b> {llm_out}</div>',
#                                 unsafe_allow_html=True,
#                             )

#                     llm_in = det.get("llm_input")
#                     llm_out = det.get("llm_output")
#                     if llm_in or llm_out:
#                         with st.popover("🔍 LLM I/O"):
#                             if llm_in:
#                                 st.markdown("**Prompt sent:**")
#                                 st.text(llm_in)
#                             st.divider()
#                             if llm_out:
#                                 st.markdown("**Response received:**")
#                                 st.text(llm_out)
#                     st.markdown("---")
#             else:
#                 st.caption("No data")

#         # ── Step 4 — Correlation (with RAG context) ──
#         with st.expander("Step 4 — Correlation & Suppression (+ LLM Narrative)", expanded=False):
#             s4 = step_outputs.get(4)
#             if s4:
#                 items = s4 if isinstance(s4, list) else [s4]
#                 if obs_rule_name:
#                     items = [c for c in items
#                              if any(d.get("rule_name") == obs_rule_name
#                                     for d in c.get("contributing_detections", []))]
#                 for cand in items:
#                     iid = cand.get("incident_id", "?")
#                     dets = cand.get("contributing_detections", [])
#                     if obs_rule_name:
#                         dets = [d for d in dets if d.get("rule_name") == obs_rule_name]
#                     # st.markdown(f"🔗  **{iid}** — {app_name}  ({len(dets)} detections)")
                    
#                     cand_app = cand.get("application", app_name).upper()
#                     cand_env = "Dev" if cand_app == "PROMPTOPT" else "Prod"
#                     cand_rule_raw = dets[0].get("rule_name", "—") if dets else "—"
#                     cand_rule = RULE_DISPLAY_NAMES.get(cand_rule_raw, cand_rule_raw)

#                     cols = st.columns(3)
#                     cols[0].metric("Environment", cand_env)
#                     cols[1].metric("Application", cand_app)
#                     cols[2].metric("Rule", cand_rule)

#                     # st.markdown(f"**Dedupe Key:** `{cand.get('dedupe_key', '—')}`")

#                     # st.markdown("**Contributing Detections:**")
#                     # for d in dets:
#                     #     emoji = result_emoji(d.get("result", ""))
#                     #     st.markdown(
#                     #         f"- {emoji} **{d.get('rule_name', '?')}** "
#                     #         f"[{d.get('result', '?')}] — {d.get('evidence', '—')}"
#                     #     )

#                     st.markdown(
#                         f'<div class="before-box">'
#                         f'<b>Grouped by:</b> application + business_date<br>'
#                         f'<b>Dedupe key:</b> {cand.get("dedupe_key", "—")}<br>'
#                         f'<b>Likely cause:</b> {cand.get("likely_cause") or "null"}'
#                         f'</div>',
#                         unsafe_allow_html=True,
#                     )

#                     rag_ctx = cand.get("rag_context")
#                     if rag_ctx:
#                         with st.expander("Retrieved Incidents (RAG Context)", expanded=False):
#                             st.text(rag_ctx)
                            
#                     graph_ctx = cand.get("graph_context")
#                     if graph_ctx:
#                         with st.expander("Knowledge Graph Context", expanded=False):
#                             st.text(graph_ctx)

#                     corr = cand.get("correlation_summary")
#                     if corr:
#                         st.markdown(
#                             f'<div class="after-box"><b>Correlation Narrative:</b><br>{corr}</div>',
#                             unsafe_allow_html=True,
#                         )

#                     llm_in = cand.get("llm_input")
#                     llm_out = cand.get("llm_output")
#                     if llm_in or llm_out:
#                         with st.popover("🔍 LLM I/O"):
#                             if llm_in:
#                                 st.markdown("**Prompt sent:**")
#                                 st.text(llm_in)
#                             st.divider()
#                             if llm_out:
#                                 st.markdown("**Response received:**")
#                                 st.text(llm_out)
#                     st.markdown("---")
#             else:
#                 st.caption("No data")

#         # ── Step 5 — Final Incident (with RAG context) ──
#         with st.expander("Step 5 — Final Incident (Severity & Routing + LLM Description)", expanded=True):
#             s5 = step_outputs.get(5)
#             if s5:
#                 items = s5 if isinstance(s5, list) else [s5]
#                 if obs_rule_name:
#                     items = [i for i in items
#                              if any(d.get("rule") == obs_rule_name
#                                     for d in i.get("evidence_summary", {}).get("detections", []))]
#                 for inc in items:
#                     iid = inc.get("incident_id", "?")
#                     sev = inc.get("severity", "—")
#                     emoji = severity_emoji(sev)
#                     colour = severity_colour(sev)

#                     inc_app = app_name.upper()
#                     inc_env = "Dev" if inc_app == "PROMPTOPT" else "Prod"
#                     inc_rule_raw = ""
#                     inc_dets_list = inc.get("evidence_summary", {}).get("detections", [])
#                     if inc_dets_list:
#                         inc_rule_raw = inc_dets_list[0].get("rule", "—")
#                     inc_rule = RULE_DISPLAY_NAMES.get(inc_rule_raw, inc_rule_raw)
#                     cols = st.columns(3)
#                     cols[0].metric("Environment", inc_env)
#                     cols[1].metric("Application", inc_app)
#                     cols[2].metric("Rule", inc_rule)

#                     # st.markdown(f"**Title:** {inc.get('title', '—')}")

#                     ev_summary = inc.get("evidence_summary", {})
#                     det_list = ev_summary.get("detections", [])
#                     if obs_rule_name:
#                         det_list = [d for d in det_list if d.get("rule") == obs_rule_name]
#                     fallback_lines = [
#                         f"Application: {app_name}",
#                         f"Severity: {sev}",
#                         f"Business Date: {ev_summary.get('business_date', '—')}",
#                         f"Detections: {len(det_list)}",
#                         "",
#                     ]
#                     for d in det_list:
#                         fallback_lines.append(
#                             f"- [{d.get('result', '?')}] {d.get('rule', '?')}: {d.get('evidence', '—')}"
#                         )

#                     rag_ctx = inc.get("rag_context")
#                     if rag_ctx:
#                         with st.expander("Retrieved Incidents (RAG Context)", expanded=False):
#                             st.text(rag_ctx)

#                     llm_out = inc.get("llm_output")
#                     description = inc.get("description", "")
#                     if llm_out:
#                         st.markdown(
#                             f'<div class="after-box"><b>LLM-Generated Description:</b><br><br>{llm_out}</div>',
#                             unsafe_allow_html=True,
#                         )
#                     elif description and not description.startswith("Application:"):
#                         st.markdown(
#                             f'<div class="after-box"><b>Description:</b><br><br>{description}</div>',
#                             unsafe_allow_html=True,
#                         )

#                     llm_in = inc.get("llm_input")
#                     if llm_in or llm_out:
#                         with st.popover("🔍 LLM I/O"):
#                             if llm_in:
#                                 st.markdown("**Prompt sent:**")
#                                 st.text(llm_in)
#                             st.divider()
#                             if llm_out:
#                                 st.markdown("**Response received:**")
#                                 st.text(llm_out)

#                     corr = inc.get("correlation_summary")
#                     if corr:
#                         with st.popover("🔗 Correlation Summary"):
#                             st.text(corr)

#                     st.caption(f"Created: {inc.get('created_at', '—')}")
#                     st.markdown("---")
#             else:
#                 st.caption("No data")

#         # Existing feedback
#         if obs.get("user_feedback"):
#             st.markdown(f"**Previous Feedback:** {obs['user_feedback']}")
#             fb_ts = obs.get("feedback_timestamp", "")
#             if hasattr(fb_ts, "strftime"):
#                 fb_ts = fb_ts.strftime("%Y-%m-%d %H:%M")
#             st.caption(f"Submitted: {fb_ts}")
#             if obs.get("analysis_correct"):
#                 st.markdown(f"**Analysis Correct:** {obs['analysis_correct']}")
#             if obs.get("feedback_user_name"):
#                 st.markdown(f"**By:** {obs['feedback_user_name']} ({obs.get('feedback_user_id', '—')})")

#         # Feedback input
#         selected_obs_id = obs.get("id", "")
        
#         # # Email notification info
#         # if obs.get("status") == "ANOMALY" and obs.get("incident_id"):
#         #     smtp_to = os.getenv("SMTP_TO", "")
#         #     if smtp_to:
#         #         st.info(f"📧 Incident {obs['incident_id']} raised — email sent to {smtp_to}")
                
                
#         analysis_correct = st.radio(
#             "Is the analysis correct?",
#             ["Yes", "No"],
#             index=0,
#             key=f"analysis_correct_{selected_obs_id}",
#         )

#         fb_col1, fb_col2 = st.columns(2)
#         with fb_col1:
#             fb_user_name = st.text_input(
#                 "Name:",
#                 key=f"fb_name_{selected_obs_id}",
#                 placeholder="Your name",
#             )
#         with fb_col2:
#             fb_user_id = st.text_input(
#                 "User ID:",
#                 key=f"fb_userid_{selected_obs_id}",
#                 placeholder="Your user ID",
#             )

#         feedback_text = st.text_area(
#             "Add feedback:",
#             key=f"feedback_input_{selected_obs_id}",
#             placeholder="e.g., This was due to planned maintenance...",
#         )

#         if st.button("Submit Feedback", key="submit_feedback"):
#             if feedback_text.strip():
#                 obs_id = str(selected_obs_id)
#                 success = update_feedback(
#                     obs_id,
#                     feedback_text.strip(),
#                     analysis_correct=analysis_correct,
#                     user_name=fb_user_name.strip(),
#                     user_id=fb_user_id.strip(),
#                 )
#                 if success:
#                     rag_store_feedback(
#                         application=obs.get("application", ""),
#                         observation_summary=(
#                             f"Rule: {obs.get('rule_name', '')} | "
#                             f"Status: {obs.get('status', '')} | "
#                             f"Evidence: {obs.get('evidence', '')}"
#                         ),
#                         feedback=feedback_text.strip(),
#                         llm_explanation=obs.get("llm_explanation", "") or "",
#                         incident_description=obs.get("incident_description", "") or "",
#                         correlation_narrative=obs.get("correlation_narrative", "") or "",
#                         analysis_correct=analysis_correct,
#                         user_name=fb_user_name.strip(),
#                         user_id=fb_user_id.strip(),
#                     )
#                     st.success("Feedback saved!")
#                     st.rerun()
#                 else:
#                     st.error("Failed to save feedback. Check logs.")
#             else:
#                 st.warning("Please enter feedback text.")




################################
"""
Observer Agent - Streamlit Dashboard
=====================================
Visualises every pipeline step with Before-LLM / After-LLM comparison.
Filter by application (ASCM, ATE, PromptOpt) via sidebar radio buttons.

Run:  streamlit run observer_advisor/streamlit_app.py
"""

from __future__ import annotations

import sys
from pathlib import Path
import os

import streamlit as st

# Ensure parent is on sys.path so imports work when run via `streamlit run`
_parent = str(Path(__file__).resolve().parent.parent)
if _parent not in sys.path:
    sys.path.insert(0, _parent)

from dotenv import load_dotenv
load_dotenv(dotenv_path=Path(__file__).resolve().parent / ".env")

from observer_advisor.logging_config import setup_logging
setup_logging()

from observer_advisor.scheduler import (
    start_scheduler, stop_scheduler, is_running, get_job_status,
)
from observer_advisor.steps.db_persistence import (
    get_observations, update_feedback, get_step_outputs,
)
from observer_advisor.tools.azure_rag import store_feedback as rag_store_feedback
from observer_advisor.tools.azure_rag import store_feedback as rag_store_feedback


# ── Helpers ───────────────────────────────────────────────────────────────────

def severity_colour(sev: str) -> str:
    return {
        "P1": "#FF4B4B",
        "P2": "#FF8C00",
        "P3": "#FFD700",
        "P4": "#4DA6FF",
    }.get(sev, "#888888")


def severity_emoji(sev: str) -> str:
    return {"P1": "🔴", "P2": "🟠", "P3": "🟡", "P4": "🔵"}.get(sev, "⚪")


def result_colour(result: str) -> str:
    return {"FAIL": "#FF4B4B", "WARNING": "#FFD700", "PASS": "#00C853"}.get(result, "#888")


def result_emoji(result: str) -> str:
    return {"FAIL": "🔴", "WARNING": "🟡", "PASS": "🟢"}.get(result, "⚪")


# ── Page config ───────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="Observer Agent Dashboard",
    page_icon="🔭",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2rem; font-weight: 700; color: #1E88E5;
        border-bottom: 3px solid #1E88E5; padding-bottom: 0.3rem;
        margin-bottom: 1rem;
    }
    .step-header {
        font-size: 1.3rem; font-weight: 600; color: #333;
        border-left: 4px solid #1E88E5; padding-left: 0.8rem;
        margin: 1.5rem 0 0.8rem 0;
    }
    .metric-card {
        background: #f8f9fa; border-radius: 8px; padding: 1rem 1.2rem;
        border: 1px solid #dee2e6; text-align: center;
    }
    .metric-value { font-size: 2rem; font-weight: 700; color: #1E88E5; }
    .metric-label { font-size: 0.85rem; color: #666; margin-top: 0.2rem; }
    .llm-box {
        background: #FFF8E1; border: 1px solid #FFD54F; border-radius: 6px;
        padding: 0.8rem 1rem; margin: 0.5rem 0; font-size: 0.85rem;
    }
    .no-llm-box {
        background: #FFEBEE; border: 1px solid #EF9A9A; border-radius: 6px;
        padding: 0.8rem 1rem; margin: 0.5rem 0; font-size: 0.85rem;
        color: #C62828;
    }
    .before-box {
        background: #F3E5F5; border: 1px solid #CE93D8; border-radius: 6px;
        padding: 0.8rem 1rem; font-size: 0.85rem;
    }
    .after-box {
        background: #E8F5E9; border: 1px solid #A5D6A7; border-radius: 6px;
        padding: 0.8rem 1rem; font-size: 0.85rem;
    }
    div[data-testid="stExpander"] { border: 1px solid #e0e0e0; border-radius: 8px; margin-bottom: 0.5rem; }
    div[data-testid="stExpander"] [data-testid="stMetricValue"] { font-size: 0.9rem; font-weight: 700; }
    div[data-testid="stExpander"] [data-testid="stMetricLabel"] { font-size: 0.7rem; }
</style>
""", unsafe_allow_html=True)


# ── Sidebar ───────────────────────────────────────────────────────────────────

with st.sidebar:
    st.markdown("## Observer Agent")
    st.divider()

    selected_app = st.radio(
        "Application",
        ["All", "ASCM", "ATE", "PromptOpt"],
        index=0,
    )

    st.divider()

    # ── Scheduler controls ──
    st.markdown("### Scheduler")

    if is_running():
        st.success("Running",)
        if st.button("Stop Scheduler"):
            stop_scheduler()
            st.rerun()

        # Show job schedule
        jobs = get_job_status()
        for job in jobs:
            st.caption(f"**{job['name']}** — next: {job['next_run']}  |  last: {job['last_run']}")
    else:
        st.warning("Stopped", )
        if st.button("Start Scheduler", type="primary"):
            start_scheduler()
            st.rerun()

    st.divider()

    # ── Run Pipeline button (manual) ──
    st.markdown("### Manual")
    if st.button("Run Pipeline Now"):
        with st.spinner("Running Observer pipeline…"):
            import subprocess, sys
            proc = subprocess.run(
                [sys.executable, "-m", "observer_advisor.main"],
                cwd=str(Path(__file__).resolve().parent.parent),
                capture_output=True,
                text=True,
                timeout=120,
            )
        if proc.returncode == 0:
            st.success("Pipeline finished! Refreshing…")
            st.cache_data.clear()
            st.rerun()
        else:
            st.error("Pipeline failed!")
            st.code(proc.stderr or proc.stdout, language="text")

    if st.button("Refresh Data", use_container_width=True):
        st.cache_data.clear()
        st.rerun()

    # Auto-refresh toggle (when scheduler is running)
    auto_refresh = st.checkbox("Auto-refresh (60s)", value=is_running())
    if auto_refresh:
        st.caption("Dashboard refreshes every 60 seconds.")

    st.caption("Reads JSON files from `outputs/` folder.")


# ── Auto-refresh (stdlib, no external package) ──────────────────────────────

if auto_refresh:
    # Use Streamlit's built-in auto-rerun via HTML meta refresh
    st.markdown(
        '<meta http-equiv="refresh" content="60">',
        unsafe_allow_html=True,
    )


# ── Load data ─────────────────────────────────────────────────────────────────

# Load observations from DB (used by tiles + incidents table)
all_observations = get_observations(limit=200)

run_ts = all_observations[0].get("timestamp", "—") if all_observations else "—"


st.markdown('<div class="main-header">Observer Agent Dashboard</div>', unsafe_allow_html=True)
st.markdown(f"**Last run:** `{run_ts}`")

# Quick stats row — anomaly count per app from DB
def _app_incident_count(app_name: str) -> int:
    return len([o for o in all_observations if o.get("application", "").upper() == app_name.upper()])

c1, c2, c3 = st.columns(3)
for col, app_name in zip([c1, c2, c3], ["ASCM", "ATE", "PromptOpt"]):
    cnt = _app_incident_count(app_name)
    col.markdown(
        f'<div class="metric-card">'
        f'<div class="metric-value">{cnt}</div>'
        f'<div class="metric-label">{app_name}</div>'
        f'</div>',
        unsafe_allow_html=True,
    )


# ═══════════════════════════════════════════════════════════════════════════════
# INCIDENTS LIST + FEEDBACK
# ═══════════════════════════════════════════════════════════════════════════════

st.divider()
st.markdown(
    '<div class="step-header">  Incidents List</div>',
    unsafe_allow_html=True,
)

observations = all_observations

# Filter by selected app
if selected_app != "All":
    observations = [o for o in observations if o.get("application", "").upper() == selected_app.upper()]

if not observations:
    st.info("No observations in the database yet.")
else:
    import pandas as pd

    # Pagination
    PAGE_SIZE = 10
    if "page" not in st.session_state:
        st.session_state.page = 0

    total_pages = max(1, (len(observations) + PAGE_SIZE - 1) // PAGE_SIZE)
    # Clamp page to valid range
    if st.session_state.page >= total_pages:
        st.session_state.page = total_pages - 1

    start_idx = st.session_state.page * PAGE_SIZE
    end_idx = start_idx + PAGE_SIZE
    page_observations = observations[start_idx:end_idx]
    
    # Build table data
    # Display-friendly rule names
    RULE_DISPLAY_NAMES = {
        "ascm_tgt_frequency": "ASCM Target Frequency",
        "ascm_fr": "ASCM FR",
        "ascm_avg_frequency": "ASCM Avg Frequency",
        "ascm_adjusted_pn": "ASCM Adjusted PN",
        # ── CHANGED: ATE rule display names ──
        "ate_trade_stuck": "ATE Trade Stuck",
        "ate_trade_failed": "ATE Trade Failed",
        "ate_retry_exhaustion": "ATE Retry Exhaustion",
    }
    
    table_data = []
    for obs_item in page_observations:
        # Format timestamp as "date time" (drop timezone/fractional seconds)
        raw_ts = obs_item.get("timestamp", "")
        if raw_ts:
            try:
                from datetime import datetime as _dt
                dt = _dt.fromisoformat(str(raw_ts))
                fmt_ts = dt.strftime("%Y-%m-%d %H:%M:%S")
            except (ValueError, TypeError):
                fmt_ts = str(raw_ts)
        else:
            fmt_ts = "—"
        
        raw_rule = obs_item.get("rule_name", "?")
        display_rule = RULE_DISPLAY_NAMES.get(raw_rule, raw_rule)
        
        table_data.append({
            "Application": obs_item.get("application", "?"),
            "Incident ID": obs_item.get("incident_id", "—") or "—",
            "Timestamp": fmt_ts,
            "Rule": display_rule,
            "Status": obs_item.get("status", "?"),
        })

    df = pd.DataFrame(table_data)

    selection = st.dataframe(
        df,
        use_container_width=True,
        hide_index=True,
        on_select="rerun",
        selection_mode="single-row",
        key="incidents_table",
    )
    
    # Pagination controls
    pcol1, pcol2, pcol3 = st.columns([1, 2, 1])
    with pcol1:
        if st.button("⬅ Previous", disabled=(st.session_state.page == 0)):
            st.session_state.page -= 1
            st.rerun()
    with pcol2:
        st.caption(f"Page {st.session_state.page + 1} of {total_pages}  ({len(observations)} total)")
    with pcol3:
        if st.button("Next ➡", disabled=(st.session_state.page >= total_pages - 1)):
            st.session_state.page += 1
            st.rerun()

    # Detail view for selected observation
    selected_rows = selection.selection.rows if selection.selection else []
    obs = page_observations[selected_rows[0]] if selected_rows else None

    if obs:
        st.divider()

        # Fetch all step outputs for this observation's pipeline run
        run_id = obs.get("run_id")
        app_name = obs.get("application", "")
        obs_rule_name = obs.get("rule_name", "")
        step_outputs = {}
        if run_id:
            for so in get_step_outputs(run_id, app_name):
                step_outputs[so["step_number"]] = so["step_output"]

        # ── CHANGED: Use incident_id to find the exact detection & check_id ──
        obs_incident_id = obs.get("incident_id", "")
        obs_check_id = None
        s3_all = step_outputs.get(3)
        if s3_all:
            dets_list = s3_all if isinstance(s3_all, list) else [s3_all]
            # First try matching by incident_id (for per-row ATE incidents)
            for d in dets_list:
                if d.get("incident_id") == obs_incident_id:
                    obs_check_id = d.get("check_id")
                    break
            # Fallback: match by rule_name (for ASCM/PromptOpt)
            if not obs_check_id:
                for d in dets_list:
                    if d.get("rule_name") == obs_rule_name:
                        obs_check_id = d.get("check_id")
                        break
        # For NORMAL observations, rule_name IS the check_id
        if not obs_check_id:
            obs_check_id = obs_rule_name

        # ── Step 1 — Raw Results ──
        with st.expander("Step 1 — Raw Results (DB Queries)", expanded=False):
            s1 = step_outputs.get(1)
            if s1:
                items = s1 if isinstance(s1, list) else [s1]
                for item in items:
                    app = item.get("application", "?")
                    err = item.get("error")
                    if "checks" in item:
                        # ── CHANGED: Match per-row check_ids to base rule ──
                        if obs_check_id:
                            filtered_checks = {}
                            for cid, cdata in item["checks"].items():
                                if cid == obs_check_id or obs_check_id.startswith(cid + "_"):
                                    filtered_checks[cid] = cdata
                        else:
                            filtered_checks = item["checks"]
                        
                        # ── Per-row ATE: show only Trade Details table ──
                        row_shown = False
                        if obs_check_id and "_" in obs_check_id:
                            row_id = obs_check_id.rsplit("_", 1)[-1]
                            for cid, cdata in filtered_checks.items():
                                for r in cdata.get("rows", []):
                                    if str(r.get("id")) == row_id:
                                        st.markdown("**Trade Details (this incident):**")
                                        row_table = [{
                                            "ID": str(r.get("id", "—")),
                                            "Exchange": r.get("exchange", "—"),
                                            "Provider": r.get("exchangeprovider", "—"),
                                            "Message Type": r.get("messagetype", "—"),
                                            "Message ID": str(r.get("messageid", "—")),
                                            "Synchstate": str(r.get("synchstate", "—")),
                                            "Status": r.get("messagestatus", "—"),
                                            "Synch Count": str(r.get("synchcount", "—")),
                                            "Last Updated": r.get("lastupdated", "—"),
                                            "Failed Reason": r.get("failedreason") or "—",
                                        }]
                                        st.dataframe(
                                            pd.DataFrame(row_table),
                                            use_container_width=True,
                                            hide_index=True,
                                        )
                                        row_shown = True
                                        break

                        # Fallback: show summary table only when no row detail was shown
                        if not row_shown:
                            s1_table = []
                            for cid, cdata in filtered_checks.items():
                                display_cid = RULE_DISPLAY_NAMES.get(cid, cid)
                                s1_table.append({
                                    "Rule": display_cid,
                                    "Source Table": cdata.get("source_table", "—"),
                                    "Value": str(cdata.get("raw_value", "null")),
                                    "Error": cdata.get("error") or "—",
                                })
                            if s1_table:
                                st.dataframe(
                                    pd.DataFrame(s1_table),
                                    use_container_width=True,
                                    hide_index=True,
                                )
                    else:
                        s1_table = [{
                            "Source Table": item.get("source_table", "—"),
                            "Value": str(item.get("raw_value", "null")),
                            "Error": err or "—",
                        }]
                        st.dataframe(
                            pd.DataFrame(s1_table),
                            use_container_width=True,
                            hide_index=True,
                        )
                    st.markdown("---")
            else:
                st.caption("No data")

        # ── Step 2 — Signals ──
        with st.expander("Step 2 — Normalized Signals (+ LLM Enrichment)", expanded=False):
            s2 = step_outputs.get(2)
            if s2:
                items = s2 if isinstance(s2, list) else [s2]
                if obs_check_id:
                    items = [s for s in items if s.get("check_id") == obs_check_id]
                for sig in items:
                    check = sig.get("check_id", "?")
                    sig_app = sig.get("application", app_name).upper()
                    sig_env = "Dev" if sig_app == "PROMPTOPT" else "Prod"
                    display_check = RULE_DISPLAY_NAMES.get(check, check)
                    cols = st.columns(3)
                    cols[0].metric("Environment", sig_env)
                    cols[1].metric("Application", sig_app)
                    cols[2].metric("Rule", display_check)

                    evidence = sig.get("evidence", {})

                    # ── CHANGED: Show row data in Step 2 evidence for ATE ──
                    row_data = evidence.get("row")
                    if row_data:
                        st.markdown(
                            f'<div class="before-box">'
                            f'<b>Evidence (deterministic):</b><br>'
                            f'Source Table: {evidence.get("source_table", "—")}<br>'
                            f'Rule: {evidence.get("rule", "—")}<br>'
                            f'Trade ID: {row_data.get("messageid", "—")} | '
                            f'Exchange: {row_data.get("exchange", "—")} | '
                            f'Synchstate: {row_data.get("synchstate", "—")} | '
                            f'Last Updated: {row_data.get("lastupdated", "—")} | '
                            f'Failed Reason: {row_data.get("failedreason") or "None"} | '
                            f'Synch Count: {row_data.get("synchcount", "—")}<br>'
                            f'Total rows for this rule: {evidence.get("total_rows", "—")}'
                            f'</div>',
                            unsafe_allow_html=True,
                        )
                    else:
                        st.markdown(
                            f'<div class="before-box">'
                            f'<b>Evidence (deterministic):</b><br>'
                            f'Source Table: {evidence.get("source_table", "—")}<br>'
                            f'Error: {evidence.get("error") or "None"}<br>'
                            f'Query: {evidence.get("query", "—")}'
                            f'</div>',
                            unsafe_allow_html=True,
                        )

                    enrichment = sig.get("enrichment", {})
                    interpretation = enrichment.get("interpretation") if isinstance(enrichment, dict) else None
                    if interpretation:
                        st.markdown(
                            f'<div class="after-box">'
                            f'<b>Interpretation:</b> {interpretation}'
                            f'</div>',
                            unsafe_allow_html=True,
                        )

                    llm_out = evidence.get("llm_output")
                    if llm_out:
                        with st.popover("🔍 LLM Response"):
                            st.text(llm_out)
                    st.markdown("---")
            else:
                st.caption("No data")

        # ── Step 3 — Detection & Validation (merged Step 3 + 3A) ──
        with st.expander("Step 3 — Detection & Validation (Rules + Business Context)", expanded=False):
            # Prefer validated data (step 3 now contains validation metadata after merge);
            s3_data = step_outputs.get(3)
            has_validation = False
            if s3_data:
                items_check = s3_data if isinstance(s3_data, list) else [s3_data]
                has_validation = any(d.get("validation") for d in items_check)
            if s3_data:
                items = s3_data if isinstance(s3_data, list) else [s3_data]
                # Filter to this observation's detection
                if obs_incident_id:
                    filtered = [d for d in items if d.get("incident_id") == obs_incident_id]
                    if not filtered and obs_rule_name:
                        filtered = [d for d in items if d.get("rule_name") == obs_rule_name]
                    items = filtered if filtered else items
                elif obs_rule_name:
                    items = [d for d in items if d.get("rule_name") == obs_rule_name]

                for det in items:
                    rule = det.get("rule_name", "?")
                    display_rule_det = RULE_DISPLAY_NAMES.get(rule, rule)

                    # ── Validation banner (top of each detection) ──
                    validation = det.get("validation", {})
                    if has_validation and validation:
                        action = validation.get("action", "KEEP")
                        orig_sev = validation.get("original_severity", "—")
                        adj_sev = validation.get("adjusted_severity", orig_sev)

                        if action == "SUPPRESS":
                            badge_color, badge_icon = "#FF4B4B", "🚫"
                        elif action == "DOWNGRADE":
                            badge_color, badge_icon = "#FFD700", "⬇️"
                        else:
                            badge_color, badge_icon = "#00C853", "✅"

                        sev_text = f"{orig_sev} → {adj_sev}" if action == "DOWNGRADE" else orig_sev
                        reasons = validation.get("reasons", [])
                        reason_str = " — " + "; ".join(reasons) if reasons else ""

                        st.markdown(
                            f'<div style="background:{badge_color}22;border:1px solid {badge_color};'
                            f'border-radius:6px;padding:0.5rem 1rem;margin-bottom:0.8rem">'
                            f'<span style="color:{badge_color};font-weight:bold;font-size:1.1rem">'
                            f'{badge_icon} {action}</span>'
                            f'&nbsp;&nbsp;|&nbsp;&nbsp;<b>Severity:</b> {sev_text}'
                            f'{reason_str}</div>',
                            unsafe_allow_html=True,
                        )

                    # ── Detection info (Environment / App / Rule) ──
                    det_app = det.get("application", app_name).upper()
                    det_env = "Dev" if det_app == "PROMPTOPT" else "Prod"
                    cols = st.columns(3)
                    cols[0].metric("Environment", det_env)
                    cols[1].metric("Application", det_app)
                    cols[2].metric("Rule", display_rule_det)

                    # ── Evidence ──
                    evidence_raw = det.get("evidence", "")
                    if " | LLM: " in str(evidence_raw):
                        before_part, after_part = str(evidence_raw).split(" | LLM: ", 1)
                    else:
                        before_part = evidence_raw
                        after_part = None

                    st.markdown(
                        f'<div class="before-box"><b>Evidence:</b> {before_part}</div>',
                        unsafe_allow_html=True,
                    )

                    # ── RAG Context ──
                    rag_ctx = det.get("rag_context")
                    if rag_ctx:
                        with st.expander("Retrieved Incidents (RAG Context)", expanded=False):
                            st.text(rag_ctx)

                    # ── LLM Explanation ──
                    if after_part:
                        st.markdown(
                            f'<div class="after-box"><b>LLM Explanation:</b> {after_part}</div>',
                            unsafe_allow_html=True,
                        )
                    else:
                        llm_out = det.get("llm_output")
                        if llm_out:
                            st.markdown(
                                f'<div class="after-box"><b>LLM Explanation:</b> {llm_out}</div>',
                                unsafe_allow_html=True,
                            )

                    # ── Validation Checks Detail (if validation ran) ──
                    if has_validation and validation:
                        checks = validation.get("checks", {})
                        if checks:
                            check_parts = []
                            for check_name, check_info in checks.items():
                                check_parts.append(
                                    f"**{check_name}**: {check_info.get('action', '?')} — "
                                    f"{check_info.get('reason', '')}"
                                )
                            with st.expander("Validation Checks Detail", expanded=False):
                                for cp in check_parts:
                                    st.markdown(cp)

                    # ── LLM I/O popovers (detection + validation side by side) ──
                    llm_in = det.get("llm_input")
                    llm_out = det.get("llm_output")
                    v_llm_in = det.get("validation_llm_input")
                    v_llm_out = det.get("validation_llm_output")

                    popover_cols = st.columns(2)
                    with popover_cols[0]:
                        if llm_in or llm_out:
                            with st.popover("🔍 Detection LLM I/O"):
                                if llm_in:
                                    st.markdown("**Prompt sent:**")
                                    st.text(llm_in)
                                st.divider()
                                if llm_out:
                                    st.markdown("**Response received:**")
                                    st.text(llm_out)
                    with popover_cols[1]:
                        if v_llm_in or v_llm_out:
                            with st.popover("🔍 Validation LLM I/O"):
                                if v_llm_in:
                                    st.markdown("**Prompt sent:**")
                                    st.text(v_llm_in)
                                st.divider()
                                if v_llm_out:
                                    st.markdown("**Response received:**")
                                    st.text(v_llm_out)

                    st.markdown("---")
            else:
                st.caption("No data")

        # ── Step 3B — Soft Anomaly Discovery ──
        with st.expander("Step 3B — Soft Anomaly Discovery (AI Pattern Analysis)", expanded=False):
            s3b_data = step_outputs.get(6)
            if s3b_data is not None:
                items_3b = s3b_data if isinstance(s3b_data, list) else [s3b_data]
                if not items_3b:
                    st.caption("No soft anomalies detected — all PASS signals look normal.")
                else:
                    st.markdown(
                        f'<div style="background:#1E88E522;border:1px solid #1E88E5;'
                        f'border-radius:6px;padding:0.5rem 1rem;margin-bottom:1rem">'
                        f'<span style="color:#1E88E5;font-weight:bold;font-size:1.1rem">'
                        f'🔎 {len(items_3b)} soft anomal{"y" if len(items_3b) == 1 else "ies"} discovered</span>'
                        f'&nbsp;&nbsp;—&nbsp;&nbsp;Patterns that passed rules but look unusual vs. baselines'
                        f'</div>',
                        unsafe_allow_html=True,
                    )
                    for sa in items_3b:
                        check_id = sa.get("check_id", "?")
                        sa_app = sa.get("application", "?")
                        risk = sa.get("risk_level", "LOW")
                        confidence = sa.get("confidence", 0)
                        category = sa.get("category", "unknown")
                        finding = sa.get("finding", "")
                        evidence = sa.get("evidence", "")

                        risk_color = "#FFD700" if risk == "MEDIUM" else "#90CAF9"
                        risk_icon = "⚠️" if risk == "MEDIUM" else "ℹ️"

                        st.markdown(
                            f'<div style="background:{risk_color}22;border:1px solid {risk_color};'
                            f'border-radius:6px;padding:0.5rem 1rem;margin-bottom:0.8rem">'
                            f'<span style="color:{risk_color};font-weight:bold;font-size:1rem">'
                            f'{risk_icon} {risk} RISK</span>'
                            f'&nbsp;&nbsp;|&nbsp;&nbsp;<b>Check:</b> {check_id}'
                            f'&nbsp;&nbsp;|&nbsp;&nbsp;<b>App:</b> {sa_app}'
                            f'&nbsp;&nbsp;|&nbsp;&nbsp;<b>Category:</b> {category}'
                            f'&nbsp;&nbsp;|&nbsp;&nbsp;<b>Confidence:</b> {confidence:.0%}'
                            f'</div>',
                            unsafe_allow_html=True,
                        )

                        st.markdown(
                            f'<div class="before-box"><b>Finding:</b> {finding}</div>',
                            unsafe_allow_html=True,
                        )

                        if evidence:
                            st.markdown(
                                f'<div class="after-box"><b>Evidence:</b> {evidence}</div>',
                                unsafe_allow_html=True,
                            )

                        sa_llm_in = sa.get("llm_input")
                        sa_llm_out = sa.get("llm_output")
                        if sa_llm_in or sa_llm_out:
                            with st.popover("🔍 Soft Anomaly LLM I/O"):
                                if sa_llm_in:
                                    st.markdown("**Prompt sent:**")
                                    st.text(sa_llm_in)
                                st.divider()
                                if sa_llm_out:
                                    st.markdown("**Response received:**")
                                    st.text(sa_llm_out)

                        st.markdown("---")
            else:
                st.caption("No soft anomaly data (Step 3B did not run or found nothing)")

        # ── Step 4 — Correlation (with RAG context) ──
        with st.expander("Step 4 — Correlation & Suppression (+ LLM Narrative)", expanded=False):
            s4 = step_outputs.get(4)
            if s4:
                items = s4 if isinstance(s4, list) else [s4]
                # ── CHANGED: Filter by incident_id first, fallback to rule_name ──
                if obs_incident_id:
                    filtered = [c for c in items if c.get("incident_id") == obs_incident_id]
                    if not filtered and obs_rule_name:
                        filtered = [c for c in items
                                     if any(d.get("rule_name") == obs_rule_name
                                            for d in c.get("contributing_detections", []))]
                    items = filtered if filtered else items
                elif obs_rule_name:
                    items = [c for c in items
                             if any(d.get("rule_name") == obs_rule_name
                                    for d in c.get("contributing_detections", []))]
                for cand in items:
                    iid = cand.get("incident_id", "?")
                    dets = cand.get("contributing_detections", [])
                    if obs_rule_name:
                        dets = [d for d in dets if d.get("rule_name") == obs_rule_name]
                    
                    cand_app = cand.get("application", app_name).upper()
                    cand_env = "Dev" if cand_app == "PROMPTOPT" else "Prod"
                    cand_rule_raw = dets[0].get("rule_name", "—") if dets else "—"
                    cand_rule = RULE_DISPLAY_NAMES.get(cand_rule_raw, cand_rule_raw)

                    cols = st.columns(3)
                    cols[0].metric("Environment", cand_env)
                    cols[1].metric("Application", cand_app)
                    cols[2].metric("Rule", cand_rule)

                    st.markdown(
                        f'<div class="before-box">'
                        f'<b>Grouped by:</b> application + business_date<br>'
                        f'<b>Dedupe key:</b> {cand.get("dedupe_key", "—")}<br>'
                        f'<b>Likely cause:</b> {cand.get("likely_cause") or "null"}'
                        f'</div>',
                        unsafe_allow_html=True,
                    )

                    rag_ctx = cand.get("rag_context")
                    if rag_ctx:
                        with st.expander("Retrieved Incidents (RAG Context)", expanded=False):
                            st.text(rag_ctx)
                            
                    graph_ctx = cand.get("graph_context")
                    if graph_ctx:
                        with st.expander("Knowledge Graph Context", expanded=False):
                            st.text(graph_ctx)

                    corr = cand.get("correlation_summary")
                    if corr:
                        st.markdown(
                            f'<div class="after-box"><b>Correlation Narrative:</b><br>{corr}</div>',
                            unsafe_allow_html=True,
                        )

                    llm_in = cand.get("llm_input")
                    llm_out = cand.get("llm_output")
                    if llm_in or llm_out:
                        with st.popover("🔍 LLM I/O"):
                            if llm_in:
                                st.markdown("**Prompt sent:**")
                                st.text(llm_in)
                            st.divider()
                            if llm_out:
                                st.markdown("**Response received:**")
                                st.text(llm_out)
                    st.markdown("---")
            else:
                st.caption("No data")

        # ── Step 5 — Final Incident (with RAG context) ──
        with st.expander("Step 5 — Final Incident (Severity & Routing + LLM Description)", expanded=True):
            s5 = step_outputs.get(5)
            if s5:
                items = s5 if isinstance(s5, list) else [s5]
                # ── CHANGED: Filter by incident_id first, fallback to rule_name ──
                if obs_incident_id:
                    filtered = [i for i in items if i.get("incident_id") == obs_incident_id]
                    if not filtered and obs_rule_name:
                        filtered = [i for i in items
                                     if any(d.get("rule") == obs_rule_name
                                            for d in i.get("evidence_summary", {}).get("detections", []))]
                    items = filtered if filtered else items
                elif obs_rule_name:
                    items = [i for i in items
                             if any(d.get("rule") == obs_rule_name
                                    for d in i.get("evidence_summary", {}).get("detections", []))]
                for inc in items:
                    iid = inc.get("incident_id", "?")
                    sev = inc.get("severity", "—")
                    emoji = severity_emoji(sev)
                    colour = severity_colour(sev)

                    inc_app = app_name.upper()
                    inc_env = "Dev" if inc_app == "PROMPTOPT" else "Prod"
                    inc_rule_raw = ""
                    inc_dets_list = inc.get("evidence_summary", {}).get("detections", [])
                    if inc_dets_list:
                        inc_rule_raw = inc_dets_list[0].get("rule", "—")
                    inc_rule = RULE_DISPLAY_NAMES.get(inc_rule_raw, inc_rule_raw)
                    cols = st.columns(3)
                    cols[0].metric("Environment", inc_env)
                    cols[1].metric("Application", inc_app)
                    cols[2].metric("Rule", inc_rule)

                    ev_summary = inc.get("evidence_summary", {})
                    det_list = ev_summary.get("detections", [])
                    if obs_rule_name:
                        det_list = [d for d in det_list if d.get("rule") == obs_rule_name]
                    fallback_lines = [
                        f"Application: {app_name}",
                        f"Severity: {sev}",
                        f"Business Date: {ev_summary.get('business_date', '—')}",
                        f"Detections: {len(det_list)}",
                        "",
                    ]
                    for d in det_list:
                        fallback_lines.append(
                            f"- [{d.get('result', '?')}] {d.get('rule', '?')}: {d.get('evidence', '—')}"
                        )

                    rag_ctx = inc.get("rag_context")
                    if rag_ctx:
                        with st.expander("Retrieved Incidents (RAG Context)", expanded=False):
                            st.text(rag_ctx)

                    llm_out = inc.get("llm_output")
                    description = inc.get("description", "")
                    if llm_out:
                        st.markdown(
                            f'<div class="after-box"><b>LLM-Generated Description:</b><br><br>{llm_out}</div>',
                            unsafe_allow_html=True,
                        )
                    elif description and not description.startswith("Application:"):
                        st.markdown(
                            f'<div class="after-box"><b>Description:</b><br><br>{description}</div>',
                            unsafe_allow_html=True,
                        )

                    llm_in = inc.get("llm_input")
                    if llm_in or llm_out:
                        with st.popover("🔍 LLM I/O"):
                            if llm_in:
                                st.markdown("**Prompt sent:**")
                                st.text(llm_in)
                            st.divider()
                            if llm_out:
                                st.markdown("**Response received:**")
                                st.text(llm_out)

                    corr = inc.get("correlation_summary")
                    if corr:
                        with st.popover("🔗 Correlation Summary"):
                            st.text(corr)

                    st.caption(f"Created: {inc.get('created_at', '—')}")
                    st.markdown("---")
            else:
                st.caption("No data")

        # Existing feedback
        if obs.get("user_feedback"):
            st.markdown(f"**Previous Feedback:** {obs['user_feedback']}")
            fb_ts = obs.get("feedback_timestamp", "")
            if hasattr(fb_ts, "strftime"):
                fb_ts = fb_ts.strftime("%Y-%m-%d %H:%M")
            st.caption(f"Submitted: {fb_ts}")
            if obs.get("analysis_correct"):
                st.markdown(f"**Analysis Correct:** {obs['analysis_correct']}")
            if obs.get("feedback_user_name"):
                st.markdown(f"**By:** {obs['feedback_user_name']} ({obs.get('feedback_user_id', '—')})")

        # Feedback input
        selected_obs_id = obs.get("id", "")
                
        analysis_correct = st.radio(
            "Is the analysis correct?",
            ["Yes", "No"],
            index=0,
            key=f"analysis_correct_{selected_obs_id}",
        )

        fb_col1, fb_col2 = st.columns(2)
        with fb_col1:
            fb_user_name = st.text_input(
                "Name:",
                key=f"fb_name_{selected_obs_id}",
                placeholder="Your name",
            )
        with fb_col2:
            fb_user_id = st.text_input(
                "User ID:",
                key=f"fb_userid_{selected_obs_id}",
                placeholder="Your user ID",
            )

        feedback_text = st.text_area(
            "Add feedback:",
            key=f"feedback_input_{selected_obs_id}",
            placeholder="e.g., This was due to planned maintenance...",
        )

        if st.button("Submit Feedback", key="submit_feedback"):
            if feedback_text.strip():
                obs_id = str(selected_obs_id)
                success = update_feedback(
                    obs_id,
                    feedback_text.strip(),
                    analysis_correct=analysis_correct,
                    user_name=fb_user_name.strip(),
                    user_id=fb_user_id.strip(),
                )
                if success:
                    rag_store_feedback(
                        application=obs.get("application", ""),
                        observation_summary=(
                            f"Rule: {obs.get('rule_name', '')} | "
                            f"Status: {obs.get('status', '')} | "
                            f"Evidence: {obs.get('evidence', '')}"
                        ),
                        feedback=feedback_text.strip(),
                        llm_explanation=obs.get("llm_explanation", "") or "",
                        incident_description=obs.get("incident_description", "") or "",
                        correlation_narrative=obs.get("correlation_narrative", "") or "",
                        analysis_correct=analysis_correct,
                        user_name=fb_user_name.strip(),
                        user_id=fb_user_id.strip(),
                    )
                    st.success("Feedback saved!")
                    st.rerun()
                else:
                    st.error("Failed to save feedback. Check logs.")
            else:
                st.warning("Please enter feedback text.")