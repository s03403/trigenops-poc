from tools.azure_rag import retrieve_logs
result = retrieve_logs(query=" this is test comment", 
                       application="ASCM")
print(result)