"""ASCM database check tool for LangGraph.

Queries the ASCM PostgreSQL database for data freshness across
multiple document types and contract metadata.
"""

from __future__ import annotations

import logging
from datetime import datetime, date

from langchain_core.tools import tool

from observer_advisor.tools.db_connections import get_ascm_connection
from observer_advisor.config import get_config

logger = logging.getLogger(__name__)


@tool
def check_ascm() -> dict:
    """Check ASCM database for data freshness across multiple checks.

    Runs multiple checks:
    - TGT_FREQUENCY: count of today's Target Frequency rows
    - FR: count of today's FR (Frequency Response) rows
    - AVG_FREQUENCY: count of today's Average Frequency rows
    - ADJUSTED_PN: last updated timestamp for Adjusted PN contracts
    Returns all results in a single dict.
    """
    use_sample = get_config().use_sample_ascm
    today = date.today().isoformat()
    results = {}

    if use_sample:
        checks = [
            {
                "check_id": "ascm_tgt_frequency",
                "table": "METADATA",
                "query": "SELECT COUNT(*) FROM METADATA WHERE DOCUMENTTYPE = 'TGT_FREQUENCY' AND DATE(TARGETDATE) = DATE('now', '-1 day')",
                "params": (),
            },
            {
                "check_id": "ascm_fr",
                "table": "METADATA",
                "query": "SELECT COUNT(*) FROM METADATA WHERE DOCUMENTTYPE = 'FR' AND DATE(TARGETDATE) = DATE('now', '-1 day')",
                "params": (),
            },
            {
                "check_id": "ascm_avg_frequency",
                "table": "METADATA",
                "query": "SELECT COUNT(*) FROM METADATA WHERE DOCUMENTTYPE = 'AVG_FREQUENCY' AND DATE(TARGETDATE) = DATE('now', '-1 day')",
                "params": (),
            },
            {
                "check_id": "ascm_adjusted_pn",
                "table": "contract_metadata",
                "query": "SELECT MAX(lastupdated) FROM contract_metadata WHERE servicename = 'ADJUSTEDPN'",
                "params": (),
            },
        ]
    else:
        # checks = [
        #     {
        #         "check_id": "ascm_tgt_frequency",
        #         "table": "ascm_web.METADATA",
        #         "query": "SELECT COUNT(*) FROM ascm_web.METADATA WHERE DOCUMENTTYPE = 'TGT_FREQUENCY' AND TARGETDATE::date = CURRENT_DATE - 1",
        #         "params": (),
        #     },
        #     {
        #         "check_id": "ascm_fr",
        #         "table": "ascm_web.METADATA",
        #         "query": "SELECT COUNT(*) FROM ascm_web.METADATA WHERE DOCUMENTTYPE = 'FR' AND TARGETDATE::date = %s::date",
        #         "params": (today,),
        #     },
        #     {
        #         "check_id": "ascm_avg_frequency",
        #         "table": "ascm_web.METADATA",
        #         "query": "SELECT COUNT(*) FROM ascm_web.METADATA WHERE DOCUMENTTYPE = 'AVG_FREQUENCY' AND TARGETDATE::date = CURRENT_DATE - 1",
        #         "params": (),
        #     },
        #     {
        #         "check_id": "ascm_adjusted_pn",
        #         "table": "ascm_web.contract_metadata",
        #         "query": "SELECT MAX(lastupdated) FROM ascm_web.contract_metadata WHERE servicename = 'ADJUSTEDPN'",
        #         "params": (),
        #     },
        # ]
        pass

    for chk in checks:
        try:
            with get_ascm_connection() as conn:
                cur = conn.cursor()
                cur.execute(chk["query"], chk["params"])
                row = cur.fetchone()
                value = row[0] if row else None

                if isinstance(value, datetime):
                    value = value.isoformat()
                if isinstance(value, date):
                    value = value.isoformat()

                results[chk["check_id"]] = {
                    "application": "ASCM",
                    "source_table": chk["table"],
                    "raw_value": value,
                    "error": None,
                }
        except Exception as e:
            logger.error(f"ASCM check {chk['check_id']} failed: {e}")
            results[chk["check_id"]] = {
                "application": "ASCM",
                "source_table": chk["table"],
                "raw_value": None,
                "error": str(e),
            }

    return {
        "application": "ASCM",
        "checks": results,
        "timestamp": datetime.now().isoformat(),
    }
