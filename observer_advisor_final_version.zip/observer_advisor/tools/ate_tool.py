"""ATE database check tool for LangGraph.

Queries the ATE database for trade stuck, trade failed,
and retry exhaustion issues in exchsync.MESSAGE.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from langchain_core.tools import tool

from observer_advisor.tools.db_connections import get_ate_connection
from observer_advisor.config import get_config

logger = logging.getLogger(__name__)


@tool
def check_ate() -> dict:
    """Check ATE database for trade errors and sync issues.

    Runs three checks against exchsync.MESSAGE:
    - Trade stuck: synchstate=1, lastupdated > 10 min ago
    - Trade failed: synchstate=5
    - Retry exhaustion: synchstate=5, synchcount >= 5
    Returns all results in a single dict.
    """
    use_sample = get_config().use_sample_ate
    results = {}

    if use_sample:
        checks = [
            {
                "check_id": "ate_trade_stuck",
                "table": "EXCHSYNC_MESSAGE",
                "query": """
                    SELECT * FROM EXCHSYNC_MESSAGE
                    WHERE synchstate = 1
                    AND lastupdated < datetime('now', '-10 minutes')
                    ORDER BY lastupdated DESC
                """,
                "params": (),
            },
            # {
            #     "check_id": "ate_trade_failed",
            #     "table": "EXCHSYNC_MESSAGE",
            #     "query": """
            #         SELECT * FROM EXCHSYNC_MESSAGE
            #         WHERE synchstate = 5
            #         ORDER BY lastupdated DESC
            #     """,
            #     "params": (),
            # },
            # {
            #     "check_id": "ate_retry_exhaustion",
            #     "table": "EXCHSYNC_MESSAGE",
            #     "query": """
            #         SELECT * FROM EXCHSYNC_MESSAGE
            #         WHERE synchstate = 5
            #         AND synchcount >= 5
            #         ORDER BY lastupdated DESC
            #     """,
            #     "params": (),
            # },
        ]
    else:
        checks = [
            {
                "check_id": "ate_trade_stuck",
                "table": "exchsync.MESSAGE",
                "query": """
                    SELECT *
                    FROM exchsync.MESSAGE
                    WHERE SYNCHSTATE = 1
                    AND LASTUPDATED < NOW() - INTERVAL '10 minutes'
                    ORDER BY LASTUPDATED DESC
                """,
                "params": {},
            },
            # {
            #     "check_id": "ate_trade_failed",
            #     "table": "exchsync.MESSAGE",
            #     "query": """
            #         SELECT *
            #         FROM exchsync.MESSAGE
            #         WHERE SYNCHSTATE = 5
            #         ORDER BY LASTUPDATED DESC
            #     """,
            #     "params": {},
            # },
            # {
            #     "check_id": "ate_retry_exhaustion",
            #     "table": "exchsync.MESSAGE",
            #     "query": """
            #         SELECT *
            #         FROM exchsync.MESSAGE
            #         WHERE SYNCHSTATE = 5
            #         AND SYNCHCOUNT >= 5
            #         ORDER BY LASTUPDATED DESC
            #     """,
            #     "params": {},
            # },
        ]

    for chk in checks:
        try:
            with get_ate_connection() as conn:
                cur = conn.cursor()
                cur.execute(chk["query"], chk["params"])
                rows = cur.fetchall()
                columns = [desc[0] for desc in cur.description]
                row_dicts = [dict(zip(columns, row)) for row in rows]
                results[chk["check_id"]] = {
                    "application": "ATE",
                    "source_table": chk["table"],
                    "raw_value": len(rows),
                    "rows": row_dicts,
                    "error": None,
                }
        except Exception as e:
            logger.error(f"ATE check {chk['check_id']} failed: {e}")
            results[chk["check_id"]] = {
                "application": "ATE",
                "source_table": chk["table"],
                "raw_value": None,
                "rows": [],
                "error": str(e),
            }

    return {
        "application": "ATE",
        "checks": results,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }