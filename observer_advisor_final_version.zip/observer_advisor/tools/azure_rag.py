"""Azure AI Search RAG for Observer-Advisor.

Uses the same index you already created (with incident history data)
to store/retrieve feedback and log context.
"""

from __future__ import annotations

import logging
import os
import uuid

from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.core.credentials import AzureKeyCredential
from openai import AzureOpenAI
from dotenv import load_dotenv
load_dotenv()

logger = logging.getLogger(__name__)


def _get_search_client() -> SearchClient:
    endpoint = os.getenv("AZURE_SEARCH_ENDPOINT", "https://ais-weu-poc-ai-01.search.windows.net")
    key = os.getenv("AZURE_SEARCH_KEY", "z5GYu4cBZqzPfNnFZSVPFaux4pxaHQeGknuN0sFsyVAzSeAmCv7M")
    index = os.getenv("AZURE_SEARCH_INDEX_NAME", "observer-incidents-one")
    return SearchClient(endpoint, index, AzureKeyCredential(key))


def _get_embedding(text: str) -> list[float]:
    client = AzureOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", "https://ais-weu-poc-ai-01.openai.azure.com/"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY", "74d07689b48a4b0d97bc7e99736ee127"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21"),
    )
    response = client.embeddings.create(
        input=text,
        model=os.getenv("AZURE_EMBEDDING_DEPLOYMENT", "text-embedding-3-large"),
    )
    return response.data[0].embedding


def retrieve_logs(query: str, application: str, k: int = 10) -> str:
    """Vector search on Azure AI Search index filtered by application."""
    try:
        logger.info(f"Retrieving logs for application: {application} with query: {query}")
        if application.startswith("ATE"):
            logger.info("Mapping application to Ate - Automated Trade Entry")
            application = "Ate - Automated Trade Entry"
        
        elif application.startswith("Prompt"):
            application  = "Prompt Optimization"
            
        else:
            application = application.upper()

        # print(f"Retrieving logs for query: {query}, application: {application}")
        client = _get_search_client()
        vector = _get_embedding(query)
        # print(vector)

        from azure.search.documents.models import VectorizedQuery
        results = client.search(
            search_text=None,
            vector_queries=[VectorizedQuery(
                vector=vector,
                k_nearest_neighbors=k,
                fields="content_vector",
            )],
            filter=f"service_offering eq 'SO: {application}'",
            top=k,
        )

        lines = []
        for doc in results:
            lines.append(
                f"[{doc.get('severity', '?')}] ({doc.get('service_offering', '?')}) "
                f"{doc.get('description', '')}"
            )
            if doc.get("closing_notes"):
                lines.append(f"  Closing Notes: {doc['closing_notes']}")

        if not lines:
            return ""
        return "\n\n".join(lines)

    except Exception as e:
        logger.warning(f"Azure Search retrieval failed: {e}")
        return ""


def retrieve_graph_context(query: str, application: str, k: int = 5) -> str:
    """Vector search on the knowledge graph index for architectural context.

    Searches the observer-knowledge-graph index for node context,
    blast radius, and dependency chain documents relevant to the query.
    Used as a fallback when Cosmos DB Gremlin is not available.
    """
    try:
        kg_index = os.getenv("AZURE_SEARCH_KG_INDEX", "observer-knowledge-graph")
        endpoint = os.getenv("AZURE_SEARCH_ENDPOINT", "endpoint")
        key = os.getenv("AZURE_SEARCH_KEY", "key")
        client = SearchClient(endpoint, kg_index, AzureKeyCredential(key))
        vector = _get_embedding(query)

        from azure.search.documents.models import VectorizedQuery
        results = client.search(
            search_text=None,
            vector_queries=[VectorizedQuery(
                vector=vector,
                k_nearest_neighbors=k,
                fields="content_vector",
            )],
            filter=f"application eq '{application}'",
            top=k,
        )

        lines = []
        for doc in results:
            doc_type = doc.get("doc_type", "unknown")
            content = doc.get("content", "")
            lines.append(f"[{doc_type}] {content}")

        if not lines:
            return ""
        return "\n\n".join(lines)

    except Exception as e:
        logger.warning(f"Knowledge graph retrieval failed: {e}")
        return ""

def store_feedback(
    application: str,
    observation_summary: str,
    feedback: str,
    llm_explanation: str = "",
    incident_description: str = "",
    correlation_narrative: str = "",
    analysis_correct: str = "",
    user_name: str = "",
    user_id: str = "",
) -> bool:
    """Store user feedback into Azure AI Search index."""
    from datetime import datetime

    content = (
        f"Description: {observation_summary}\n"
        f"Closing Notes: {feedback}\n"
        f"Service Offering: SO: {application}\n"
        f"Severity: INFO\n"
        f"Urgency: {analysis_correct}\n"
        f"Type: user_feedback"
    )

    try:
        vector = _get_embedding(content)
        client = _get_search_client()

        doc = {
            "id": str(uuid.uuid4()),
            "content": content,
            "description": observation_summary,
            "closing_notes": (
                f"User Feedback: {feedback}\n"
                f"LLM Explanation: {llm_explanation}\n"
                f"Correlation: {correlation_narrative}\n"
                f"Incident Description: {incident_description}\n"
                f"By: {user_name} ({user_id})"
            ),
            "severity": "INFO",
            "service_offering": f"SO: {application}",
            "urgency": analysis_correct,
            "type": "user_feedback",
            "content_vector": vector,
        }

        client.upload_documents([doc])
        logger.info(f"Stored feedback for {application} in Azure AI Search")
        return True

    except Exception as e:
        logger.warning(f"Failed to store feedback in Azure Search: {e}")
        return False