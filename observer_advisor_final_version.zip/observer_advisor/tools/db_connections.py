"""Database connection helpers.

Supports real PostgreSQL/Oracle connections and a local SQLite fallback
when USE_SAMPLE_DB=true for testing.
"""

from __future__ import annotations

import os
import sqlite3
import logging
from contextlib import contextmanager
import token
from typing import Generator

from observer_advisor.config import get_config

logger = logging.getLogger(__name__)


# ── Azure AD Token Provider ───────────────────────────────────────────────────

_cached_token = None
_token_expiry = 0


def _get_azure_token() -> str:
    """Get an Azure AD access token for PostgreSQL.

    Caches the token and auto-refreshes when within 5 minutes of expiry.
    Prioritizes AzureCliCredential (local dev) over ManagedIdentity (Azure production).
    """
    import time
    global _cached_token, _token_expiry

    if _cached_token and time.time() < _token_expiry - 300:
        return _cached_token

    from azure.identity import ChainedTokenCredential, AzureCliCredential, ManagedIdentityCredential
    
    # Try CLI first (works with `az login`), then fallback to managed identity (Azure-hosted)
    credential = ChainedTokenCredential(
        AzureCliCredential(),
        ManagedIdentityCredential()
    )
    token = credential.get_token("https://ossrdbms-aad.database.windows.net/.default")
    _cached_token = token.token          # ✅ correct
    _token_expiry = token.expires_on     # ✅ correct
    logger.info("Azure AD token refreshed, expires at %s", time.ctime(_token_expiry))
    print(f"[TOKEN] Generated: {_cached_token[:50]}... | Expires: {time.ctime(_token_expiry)}")
    return _cached_token


def _get_pg_password(static_password: str) -> str:
    """Return token if USE_TOKEN_AUTH is true, else the static password."""
    if get_config().use_token_auth:
        return _get_azure_token()
    return static_password


def _use_sample() -> bool:
    return get_config().use_sample_db


def _use_sample_ascm() -> bool:
    return get_config().use_sample_ascm


def _use_sample_ate() -> bool:
    return get_config().use_sample_ate


def _use_sample_promptopt() -> bool:
    return get_config().use_sample_promptopt


# ── SQLite (testing) ──────────────────────────────────────────────────────────

SAMPLE_ASCM_DB_PATH = os.path.join(os.path.dirname(__file__), "sample_ascm.db")
SAMPLE_ATE_DB_PATH = os.path.join(os.path.dirname(__file__), "sample_ate.db")
SAMPLE_PROMPTOPT_DB_PATH = os.path.join(os.path.dirname(__file__), "sample_promptopt.db")


@contextmanager
def _sample_ascm_connection() -> Generator:
    conn = sqlite3.connect(SAMPLE_ASCM_DB_PATH)
    try:
        yield conn
    finally:
        conn.close()


@contextmanager
def _sample_ate_connection() -> Generator:
    conn = sqlite3.connect(SAMPLE_ATE_DB_PATH)
    try:
        yield conn
    finally:
        conn.close()


@contextmanager
def _sample_promptopt_connection() -> Generator:
    conn = sqlite3.connect(SAMPLE_PROMPTOPT_DB_PATH)
    try:
        yield conn
    finally:
        conn.close()


# ── ASCM (PostgreSQL) ────────────────────────────────────────────────────────

@contextmanager
def get_ascm_connection() -> Generator:
    if _use_sample_ascm():
        with _sample_ascm_connection() as conn:
            yield conn
        return
    

    import psycopg2
    cfg = get_config().ascm_db
    # print(f"[ASCM] Token generate: {_get_pg_password(cfg.password)}")
    conn = psycopg2.connect(
        host=cfg.host, 
        database=cfg.database,
        user=cfg.user, 
        password=_get_pg_password(cfg.password),
        # port=cfg.port, options=f"-c search_path={cfg.schema}",
        port=cfg.port, sslmode="require",
        options=f"-c search_path={cfg.schema}",
    )
    try:
        yield conn
    finally:
        conn.close()


# ── PromptOpt (PostgreSQL) ───────────────────────────────────────────────────

@contextmanager
def get_promptopt_connection() -> Generator:
    if _use_sample_promptopt():
        with _sample_promptopt_connection() as conn:
            yield conn
        return

    import psycopg2
    cfg = get_config().promptopt_db
    conn = psycopg2.connect(
        host=cfg.host, database=cfg.database,
        user=cfg.user, password=_get_pg_password(cfg.password),
        # port=cfg.port, options=f"-c search_path={cfg.schema}",
        port=cfg.port, sslmode="require",
        options=f"-c search_path={cfg.schema}",
    )
    try:
        yield conn
    finally:
        conn.close()


# ── ATE (PostgreSQL) ───────────────────────────────────────────────────────

@contextmanager
def get_ate_connection() -> Generator:
    if _use_sample_ate():
        with _sample_ate_connection() as conn:
            yield conn
        return

    import psycopg2
    cfg = get_config().ate_db
    conn = psycopg2.connect(
        host=cfg.host, database=cfg.database,
        user=cfg.user, password=_get_pg_password(cfg.password),
        port=cfg.port, sslmode="require",
        options=f"-c search_path={cfg.schema}",
    )
    try:
        yield conn
    finally:
        conn.close()


# ── Results DB (PostgreSQL or SQLite for testing) ────────────────────────────

SAMPLE_RESULTS_DB_PATH = os.path.join(os.path.dirname(__file__), "sample_results.db")

_results_table_created = False


def _ensure_results_table(conn):
    """Auto-create observation_log and pipeline_run_log tables in SQLite if they don't exist."""
    global _results_table_created
    if _results_table_created:
        return
    conn.execute("""
        CREATE TABLE IF NOT EXISTS observation_log (
            id                      TEXT PRIMARY KEY,
            run_id                  TEXT,
            timestamp               TEXT NOT NULL,
            application             TEXT NOT NULL,
            status                  TEXT NOT NULL,
            rule_name               TEXT NOT NULL,
            evidence                TEXT,
            llm_explanation         TEXT,
            rag_context             TEXT,
            severity                TEXT,
            incident_id             TEXT,
            correlation_narrative   TEXT,
            incident_description    TEXT,
            user_feedback           TEXT,
            feedback_timestamp      TEXT,
            analysis_correct        TEXT,
            feedback_user_name      TEXT,
            feedback_user_id        TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS pipeline_run_log (
            id              TEXT PRIMARY KEY,
            run_id          TEXT NOT NULL,
            timestamp       TEXT NOT NULL,
            step_number     INTEGER NOT NULL,
            application     TEXT NOT NULL,
            step_output     TEXT
        )
    """)
    conn.commit()
    _results_table_created = True


@contextmanager
def get_results_connection() -> Generator:
    if get_config().use_sample_results:
        conn = sqlite3.connect(SAMPLE_RESULTS_DB_PATH)
        _ensure_results_table(conn)
        try:
            yield conn
        finally:
            conn.close()
        return

    import psycopg2
    cfg = get_config().results_db
    conn = psycopg2.connect(
        host=cfg.host, database=cfg.database,
        user=cfg.user, password=_get_pg_password(cfg.password),
        # port=cfg.port,
        port=cfg.port, sslmode="require",
    )
    try:
        yield conn
    finally:
        conn.close()
