import os
import smtplib
from email.mime.text import MIMEText

def send_incident_email(incident: dict):
    """Send email notification for a detected incident."""
    severity = incident.get("severity", "?")
    app = incident.get("application", "?")
    inc_id = incident.get("incident_id", "?")
    env = incident.get("environment", "PROD")
    assignment = incident.get("assignment_group", "?")
    description = incident.get("description", "No description available")
    created_at = incident.get("created_at", "?")

    body = f"""INCIDENT DETECTED
─────────────────
Incident ID:  {inc_id}
Severity:     {severity}
Application:  {app}
Environment:  {env}
Detected at:  {created_at}
Assignment:   {assignment}

DESCRIPTION (LLM-generated)
────────────────────────────
{description}
"""

    msg = MIMEText(body)
    msg["Subject"] = f"[{severity}] [{app}] {inc_id}"
    msg["From"] = os.getenv("SMTP_FROM")
    msg["To"] = os.getenv("SMTP_TO")

    with smtplib.SMTP(os.getenv("SMTP_HOST"), int(os.getenv("SMTP_PORT", 587))) as server:
        server.starttls()
        server.login(os.getenv("SMTP_USER"), os.getenv("SMTP_PASSWORD"))
        server.send_message(msg)