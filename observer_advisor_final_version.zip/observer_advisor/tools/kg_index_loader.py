"""One-time loader: Knowledge Graph JSON → Azure AI Search index.

Reads ALL JSON files from json_files_graph/ folder, converts each entry
to a natural language document, generates embeddings, and uploads them
to the 'observer-knowledge-graph' Azure AI Search index.

Files ingested:
  - nodes.json              → node_catalog docs
  - edges.json              → edge docs
  - adjacency_enriched_kg.json → node_context docs (richest per-node view)
  - upstream_downstream.json   → upstream/downstream docs
  - blast_radius.json          → blast_radius docs
  - dependency_chains.json     → dependency_chain docs

Usage:
    python -m observer_advisor.tools.kg_index_loader
"""

from __future__ import annotations

import json
import logging
import os
import uuid

from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex,
    SimpleField,
    SearchableField,
    SearchField,
    SearchFieldDataType,
    VectorSearch,
    HnswAlgorithmConfiguration,
    VectorSearchProfile,
)
from azure.core.credentials import AzureKeyCredential
from openai import AzureOpenAI
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

KG_INDEX_NAME = os.getenv("AZURE_SEARCH_KG_INDEX", "observer-knowledge-graph")
JSON_DIR = os.path.join(os.path.dirname(__file__), "..", "json_files_graph")

# Node ID → application mapping for metadata filtering
_NODE_APP_MAP = {
    "sys_ATE_Core": "ATE", "sys_ATE_EXCHSYNC": "ATE", "sys_ATE_API": "ATE",
    "sys_ATE_Data": "ATE", "sys_ATE_Auditor": "ATE",
    "sys_TradeEventListener": "ATE", "sys_UKP_Portal": "ATE",
    "conn_Trayport": "ATE", "conn_ICE": "ATE", "conn_Nordpool": "ATE",
    "conn_EPEXAuction": "ATE", "conn_PosMan": "ATE",
    "exch_Trayport": "ATE", "exch_ICE": "ATE", "exch_Nordpool": "ATE",
    "exch_EPEX": "ATE",
    "sys_MasterData": "ASCM",
    "sys_Fuse": "ATE", "sys_Endur": "ATE", "sys_Fenix": "ATE",
    "sys_PosMan_AST": "ATE", "sys_PosMan_MGMT": "ATE",
    "sys_PosMan_Auditor": "ATE",
    "conn_CashOut": "ATE",
}


def _get_embedding(text: str) -> list[float]:
    client = AzureOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", ""),
        api_key=os.getenv("AZURE_OPENAI_API_KEY", ""),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", ""),
    )
    resp = client.embeddings.create(
        input=text,
        model=os.getenv("AZURE_EMBEDDING_DEPLOYMENT", "text-embedding-3-large"),
    )
    return resp.data[0].embedding


def _get_index_client() -> SearchIndexClient:
    endpoint = os.getenv("AZURE_SEARCH_ENDPOINT", "")
    key = os.getenv("AZURE_SEARCH_KEY", "")
    return SearchIndexClient(endpoint, AzureKeyCredential(key))


def _get_search_client() -> SearchClient:
    endpoint = os.getenv("AZURE_SEARCH_ENDPOINT", "")
    key = os.getenv("AZURE_SEARCH_KEY", "")
    return SearchClient(endpoint, KG_INDEX_NAME, AzureKeyCredential(key))


def _app_for_node(node_id: str) -> str:
    return _NODE_APP_MAP.get(node_id, "ATE")


def _load_node_names() -> dict[str, str]:
    """Load id→name lookup from nodes.json."""
    path = os.path.join(JSON_DIR, "nodes.json")
    with open(path, encoding="utf-8") as f:
        nodes = json.load(f)
    return {n["id"]: n["name"] for n in nodes}


def _create_index():
    """Create the Azure AI Search index for knowledge graph documents."""
    index_client = _get_index_client()

    sample = _get_embedding("test")
    dims = len(sample)

    fields = [
        SimpleField(name="id", type=SearchFieldDataType.String, key=True),
        SearchableField(name="content", type=SearchFieldDataType.String),
        SimpleField(name="node_id", type=SearchFieldDataType.String, filterable=True),
        SimpleField(name="category", type=SearchFieldDataType.String, filterable=True),
        SimpleField(name="doc_type", type=SearchFieldDataType.String, filterable=True),
        SimpleField(name="application", type=SearchFieldDataType.String, filterable=True),
        SearchField(
            name="content_vector",
            type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
            searchable=True,
            vector_search_dimensions=dims,
            vector_search_profile_name="kg-vector-profile",
        ),
    ]

    vector_search = VectorSearch(
        algorithms=[HnswAlgorithmConfiguration(name="kg-hnsw")],
        profiles=[VectorSearchProfile(name="kg-vector-profile", algorithm_configuration_name="kg-hnsw")],
    )

    index = SearchIndex(name=KG_INDEX_NAME, fields=fields, vector_search=vector_search)
    index_client.create_or_update_index(index)
    logger.info(f"Created/updated index '{KG_INDEX_NAME}' with {dims}-dim vectors")


# ── Document builders (one per JSON file) ─────────────────────────────────────

def _build_nodes_docs() -> list[dict]:
    """Build docs from nodes.json — flat catalog of all entities."""
    path = os.path.join(JSON_DIR, "nodes.json")
    with open(path, encoding="utf-8") as f:
        nodes = json.load(f)

    docs = []
    for node in nodes:
        parts = [f"{node['name']} is a {node['category']}."]
        if node.get("description"):
            parts.append(node["description"])
        content = " ".join(parts)
        docs.append({
            "id": str(uuid.uuid4()),
            "content": content,
            "node_id": node["id"],
            "category": node["category"],
            "doc_type": "node_catalog",
            "application": _app_for_node(node["id"]),
        })
    return docs


def _build_edges_docs() -> list[dict]:
    """Build docs from edges.json — one doc per directed edge."""
    path = os.path.join(JSON_DIR, "edges.json")
    with open(path, encoding="utf-8") as f:
        edges = json.load(f)

    id_to_name = _load_node_names()

    docs = []
    for edge in edges:
        from_name = id_to_name.get(edge["from"], edge["from"])
        to_name = id_to_name.get(edge["to"], edge["to"])
        rel = edge["relationship"]
        content = (
            f"{from_name} sends {rel} to {to_name}. "
            f"This is a {edge.get('style', 'solid')} connection "
            f"from {from_name} to {to_name} carrying {rel} data."
        )
        docs.append({
            "id": str(uuid.uuid4()),
            "content": content,
            "node_id": edge["from"],
            "category": "edge",
            "doc_type": "edge",
            "application": _app_for_node(edge["from"]),
        })
    return docs


def _build_adjacency_docs() -> list[dict]:
    """Build docs from adjacency_enriched_kg.json — richest per-node view."""
    path = os.path.join(JSON_DIR, "adjacency_enriched_kg.json")
    with open(path, encoding="utf-8") as f:
        nodes = json.load(f)

    id_to_name = {n["id"]: n["name"] for n in nodes}

    docs = []
    for node in nodes:
        parts = [f"{node['name']} is a {node['category']}."]
        if node.get("description"):
            parts.append(node["description"])

        incoming = node.get("incoming", [])
        if incoming:
            sources = [
                f"{id_to_name.get(e['from'], e['from'])} ({e['relationship']})"
                for e in incoming
            ]
            parts.append(f"It receives data from: {', '.join(sources)}.")

        outgoing = node.get("outgoing", [])
        if outgoing:
            targets = [
                f"{id_to_name.get(e['to'], e['to'])} ({e['relationship']})"
                for e in outgoing
            ]
            parts.append(f"It sends data to: {', '.join(targets)}.")

        content = " ".join(parts)
        docs.append({
            "id": str(uuid.uuid4()),
            "content": content,
            "node_id": node["id"],
            "category": node["category"],
            "doc_type": "node_context",
            "application": _app_for_node(node["id"]),
        })
    return docs


def _build_upstream_downstream_docs() -> list[dict]:
    """Build docs from upstream_downstream.json — upstream/downstream lists."""
    path = os.path.join(JSON_DIR, "upstream_downstream.json")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)

    id_to_name = _load_node_names()

    docs = []
    for node_id, upstream_list in data.get("upstream", {}).items():
        node_name = id_to_name.get(node_id, node_id)
        if upstream_list:
            up_names = [id_to_name.get(n, n) for n in upstream_list]
            content = (
                f"Upstream dependencies of {node_name}: "
                f"{', '.join(up_names)} feed data into {node_name}. "
                f"Total {len(up_names)} upstream systems."
            )
        else:
            content = f"{node_name} has no upstream dependencies. It is a source node."
        docs.append({
            "id": str(uuid.uuid4()),
            "content": content,
            "node_id": node_id,
            "category": "upstream",
            "doc_type": "upstream",
            "application": _app_for_node(node_id),
        })

    for node_id, downstream_list in data.get("downstream", {}).items():
        node_name = id_to_name.get(node_id, node_id)
        if downstream_list:
            down_names = [id_to_name.get(n, n) for n in downstream_list]
            content = (
                f"Downstream dependents of {node_name}: "
                f"{node_name} feeds data to {', '.join(down_names)}. "
                f"Total {len(down_names)} downstream systems."
            )
        else:
            content = f"{node_name} has no downstream dependents. It is a sink node."
        docs.append({
            "id": str(uuid.uuid4()),
            "content": content,
            "node_id": node_id,
            "category": "downstream",
            "doc_type": "downstream",
            "application": _app_for_node(node_id),
        })
    return docs


def _build_blast_radius_docs() -> list[dict]:
    """Build docs from blast_radius.json — impact analysis per node."""
    path = os.path.join(JSON_DIR, "blast_radius.json")
    with open(path, encoding="utf-8") as f:
        blast = json.load(f)

    id_to_name = _load_node_names()

    docs = []
    for node_id, data in blast.items():
        node_name = id_to_name.get(node_id, node_id)
        if data["count"] == 0:
            content = f"Blast radius for {node_name}: If {node_name} fails, no other nodes are impacted."
        else:
            impacted_names = [id_to_name.get(n, n) for n in data["impactedNodes"]]
            cat_summary = ", ".join(f"{v} {k}" for k, v in data["byCategory"].items())
            content = (
                f"Blast radius for {node_name}: If {node_name} fails, "
                f"{data['count']} nodes are impacted. "
                f"By category: {cat_summary}. "
                f"Impacted systems: {', '.join(impacted_names)}."
            )
        docs.append({
            "id": str(uuid.uuid4()),
            "content": content,
            "node_id": node_id,
            "category": "blast_radius",
            "doc_type": "blast_radius",
            "application": _app_for_node(node_id),
        })
    return docs


def _build_dependency_chain_docs() -> list[dict]:
    """Build docs from dependency_chains.json — full trade flow paths."""
    path = os.path.join(JSON_DIR, "dependency_chains.json")
    with open(path, encoding="utf-8") as f:
        chains = json.load(f)

    docs = []
    seen = set()
    for source_id, paths in chains.get("paths", {}).items():
        for chain in paths:
            steps = [f"{s['name']} ({s['category']})" for s in chain]
            path_str = " → ".join(steps)

            if path_str in seen:
                continue
            seen.add(path_str)

            sink_name = chain[-1]["name"] if chain else "unknown"
            source_name = chain[0]["name"] if chain else "unknown"

            content = (
                f"Trade flow path: {path_str}. "
                f"This is a {len(chain)}-hop path from {source_name} to {sink_name}."
            )

            app = "ATE"
            for step in chain:
                mapped = _app_for_node(step["id"])
                if mapped != "ATE":
                    app = mapped
                    break

            docs.append({
                "id": str(uuid.uuid4()),
                "content": content,
                "node_id": source_id,
                "category": "dependency_chain",
                "doc_type": "dependency_chain",
                "application": app,
            })
    return docs


# ── Upload ────────────────────────────────────────────────────────────────────

def _upload_docs(docs: list[dict]):
    """Generate embeddings and upload documents to Azure AI Search."""
    client = _get_search_client()

    batch = []
    for i, doc in enumerate(docs):
        doc["content_vector"] = _get_embedding(doc["content"])
        batch.append(doc)

        if len(batch) >= 16:
            client.upload_documents(batch)
            logger.info(f"Uploaded {i + 1}/{len(docs)} documents")
            batch = []

    if batch:
        client.upload_documents(batch)
        logger.info(f"Uploaded {len(docs)}/{len(docs)} documents")


def load_knowledge_graph():
    """Main entry: create index and load ALL JSON files."""
    print("Creating Azure AI Search index...")
    _create_index()

    builders = [
        ("nodes.json (node catalog)", _build_nodes_docs),
        ("edges.json (edges)", _build_edges_docs),
        ("adjacency_enriched_kg.json (node context)", _build_adjacency_docs),
        ("upstream_downstream.json (upstream/downstream)", _build_upstream_downstream_docs),
        ("blast_radius.json (blast radius)", _build_blast_radius_docs),
        ("dependency_chains.json (dependency chains)", _build_dependency_chain_docs),
    ]

    all_docs = []
    for label, builder in builders:
        print(f"Building docs from {label}...")
        docs = builder()
        print(f"  {len(docs)} documents")
        all_docs.extend(docs)

    print(f"\nUploading {len(all_docs)} total documents...")
    _upload_docs(all_docs)
    print("Done.")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    load_knowledge_graph()
