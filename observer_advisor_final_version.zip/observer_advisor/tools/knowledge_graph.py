"""Knowledge Graph client for Azure Cosmos DB Gremlin API.

Provides connection management and query functions for the
UK Power Trading architecture knowledge graph.
"""

from __future__ import annotations

import os
import logging
from typing import Any

from gremlin_python.driver import client, serializer

logger = logging.getLogger(__name__)

# ── Connection ────────────────────────────────────────────────────────────────

_gremlin_client: client.Client | None = None


def _get_client() -> client.Client:
    """Return a cached Gremlin client, creating one on first call."""
    global _gremlin_client
    if _gremlin_client is not None:
        return _gremlin_client

    endpoint = os.getenv("COSMOS_GREMLIN_ENDPOINT", "")
    key = os.getenv("COSMOS_GREMLIN_KEY", "")
    database = os.getenv("COSMOS_GREMLIN_DATABASE", "")
    graph = os.getenv("COSMOS_GREMLIN_GRAPH", "")

    if not all([endpoint, key, database, graph]):
        raise RuntimeError(
            "Missing Cosmos Gremlin config. Set COSMOS_GREMLIN_ENDPOINT, "
            "COSMOS_GREMLIN_KEY, COSMOS_GREMLIN_DATABASE, COSMOS_GREMLIN_GRAPH."
        )

    _gremlin_client = client.Client(
        url=endpoint,
        traversal_source="g",
        username=f"/dbs/{database}/colls/{graph}",
        password=key,
        message_serializer=serializer.GraphSONSerializersV2d0(),
    )
    logger.info("Connected to Cosmos Gremlin: %s / %s", database, graph)
    return _gremlin_client


def _run(query: str) -> list[Any]:
    """Execute a Gremlin query and return the result list."""
    c = _get_client()
    result_set = c.submit(query)
    return result_set.all().result()


# ── Query Functions ───────────────────────────────────────────────────────────

# Mapping from pipeline application names to graph vertex IDs
APP_VERTEX_MAP: dict[str, list[str]] = {
    "ATE": [
        "sys:ATE_Core", "sys:ATE_EXCHSYNC", "sys:ATE_API",
        "sys:ATE_Data", "sys:TradeEventListener",
    ],
    "ASCM": ["sys:MasterData"],
    "PROMPTOPT": [],
}


def get_upstream(vertex_id: str, max_depth: int = 5) -> list[dict]:
    """Get all systems that feed data INTO the given vertex.

    Returns a list of paths (each path is a list of vertex names).
    """
    query = (
        f"g.V('{vertex_id}')"
        f".repeat(__.in().simplePath()).times({max_depth}).emit()"
        f".path().by('name')"
        f".limit(20)"
    )
    try:
        return _run(query)
    except Exception as e:
        logger.warning("Graph query get_upstream failed: %s", e)
        return []


def get_downstream(vertex_id: str, max_depth: int = 5) -> list[dict]:
    """Get all systems that receive data FROM the given vertex.

    Returns a list of paths (each path is a list of vertex names).
    """
    query = (
        f"g.V('{vertex_id}')"
        f".repeat(__.out().simplePath()).times({max_depth}).emit()"
        f".path().by('name')"
        f".limit(20)"
    )
    try:
        return _run(query)
    except Exception as e:
        logger.warning("Graph query get_downstream failed: %s", e)
        return []


def find_path(source_id: str, target_id: str, max_depth: int = 10) -> list[dict]:
    """Find data-flow path(s) between two vertices.

    Returns paths as lists of vertex names, or empty if no path exists.
    """
    query = (
        f"g.V('{source_id}')"
        f".repeat(__.out().simplePath()).until(hasId('{target_id}')).times({max_depth})"
        f".path().by('name')"
        f".limit(5)"
    )
    try:
        return _run(query)
    except Exception as e:
        logger.warning("Graph query find_path failed: %s", e)
        return []


def get_impact_count(vertex_id: str) -> int:
    """Count how many unique downstream systems are affected if this vertex fails."""
    query = (
        f"g.V('{vertex_id}')"
        f".repeat(__.out().simplePath()).emit().dedup().count()"
    )
    try:
        result = _run(query)
        return result[0] if result else 0
    except Exception as e:
        logger.warning("Graph query get_impact_count failed: %s", e)
        return 0


def get_neighbors(vertex_id: str) -> list[dict]:
    """Get immediate neighbors (in and out) with edge labels."""
    query = (
        f"g.V('{vertex_id}').bothE()"
        f".project('edge','from','to')"
        f".by(label())"
        f".by(outV().values('name'))"
        f".by(inV().values('name'))"
    )
    try:
        return _run(query)
    except Exception as e:
        logger.warning("Graph query get_neighbors failed: %s", e)
        return []


def get_graph_context_for_apps(app_a: str, app_b: str) -> str:
    """Build a text summary of graph relationships between two applications.

    Used by the Step 4 correlator to enrich the LLM prompt with
    architectural context.
    """
    vertices_a = APP_VERTEX_MAP.get(app_a.upper(), [])
    vertices_b = APP_VERTEX_MAP.get(app_b.upper(), [])

    if not vertices_a or not vertices_b:
        return "No graph context available for these applications."

    lines: list[str] = []
    for va in vertices_a:
        for vb in vertices_b:
            paths = find_path(va, vb)
            if paths:
                for p in paths:
                    path_str = " → ".join(p) if isinstance(p, list) else str(p)
                    lines.append(f"  Path: {path_str}")
            # Also check reverse direction
            paths_rev = find_path(vb, va)
            if paths_rev:
                for p in paths_rev:
                    path_str = " → ".join(p) if isinstance(p, list) else str(p)
                    lines.append(f"  Path (reverse): {path_str}")

    if not lines:
        return f"No direct data-flow path found between {app_a} and {app_b} systems."

    header = f"Architectural data-flow paths between {app_a} and {app_b}:"
    return header + "\n" + "\n".join(lines)


def close():
    """Close the Gremlin client connection."""
    global _gremlin_client
    if _gremlin_client is not None:
        _gremlin_client.close()
        _gremlin_client = None
        logger.info("Gremlin client closed.")
